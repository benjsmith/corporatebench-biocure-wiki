---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_alicia_meza_201e.txt
ingested_at: 2026-08-29T18:48:02.099127+00:00
sha256: 1683c689f07fcec1e935e238a0c9e934deb211e54433534032bb1d5ebda72f20
bytes: 616
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Working Session: hepatic-renal clearance synthesis

From: Alicia Meza <Lmeza@biocuresolutions.com>
To: Freddy Black <freddyblack@biocuresolutions.com>, Alicia Meza <Lmeza@biocuresolutions.com>
Date: 2024-02-21

CALENDAR INVITE

You are invited to: Working Session: hepatic-renal clearance synthesis
Scheduled for: 2024-02-21

Organizer: Alicia Meza (Lmeza@biocuresolutions.com)

Attendees:
  - Freddy Black (freddyblack@biocuresolutions.com)
  - Alicia Meza (Lmeza@biocuresolutions.com)

This meeting has been scheduled by Alicia Meza.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
