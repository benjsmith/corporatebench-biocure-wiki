---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_eric_wesack_85d6.txt
ingested_at: 2026-08-29T18:48:05.920831+00:00
sha256: 6f4dcce94bb028b04950c44138bb828efedc6aa56ff7d9cffe0a330a79634003
bytes: 1885
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Process Improvement Team Standup

From: Eric Wesack <Rwesack@biocuresolutions.com>
To: Lena Martin <Ellen@biocuresolutions.com>, James Zaragoza <Jamie@biocuresolutions.com>, Jose Brown <brown.jose@biocuresolutions.com>, Holly Wilson <hollywilson@biocuresolutions.com>, Mark Lawson <mark_lawson@biocuresolutions.com>, Gertrud Thompson <thompson.gertrud@biocuresolutions.com>, Eric Wesack <Rwesack@biocuresolutions.com>, Roger Wilson <Rodger.w@biocuresolutions.com>, Teresa Rice <Terry.r@biocuresolutions.com>, Teodoro Wilson <teodoro_wilson@biocuresolutions.com>, Edelbert Rice <rice.edelbert@biocuresolutions.com>, Cynthia Thompson <Cinthathompson@biocuresolutions.com>, Carolyn Schroder <Cassie.s@biocuresolutions.com>, Laura Schmitz <lschmitz@biocuresolutions.com>, Paul Kidd <P.kidd@biocuresolutions.com>
Date: 2024-03-04

CALENDAR INVITE

You are invited to: Process Improvement Team Standup
Scheduled for: 2024-03-04

Organizer: Eric Wesack (Rwesack@biocuresolutions.com)

Attendees:
  - Lena Martin (Ellen@biocuresolutions.com)
  - James Zaragoza (Jamie@biocuresolutions.com)
  - Jose Brown (brown.jose@biocuresolutions.com)
  - Holly Wilson (hollywilson@biocuresolutions.com)
  - Mark Lawson (mark_lawson@biocuresolutions.com)
  - Gertrud Thompson (thompson.gertrud@biocuresolutions.com)
  - Eric Wesack (Rwesack@biocuresolutions.com)
  - Roger Wilson (Rodger.w@biocuresolutions.com)
  - Teresa Rice (Terry.r@biocuresolutions.com)
  - Teodoro Wilson (teodoro_wilson@biocuresolutions.com)
  - Edelbert Rice (rice.edelbert@biocuresolutions.com)
  - Cynthia Thompson (Cinthathompson@biocuresolutions.com)
  - Carolyn Schroder (Cassie.s@biocuresolutions.com)
  - Laura Schmitz (lschmitz@biocuresolutions.com)
  - Paul Kidd (P.kidd@biocuresolutions.com)

This meeting has been scheduled by Eric Wesack.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
