---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_debora_alexander_20c0.txt
ingested_at: 2026-08-29T18:48:05.143813+00:00
sha256: e686821e0e66642137a4ce7b5b7e97779351175f09e89423be61f189850efbad
bytes: 659
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Debora Alexander + Martin Fullerton Sync

From: Debora Alexander <alexander.Deb@biocuresolutions.com>
To: Martin Fullerton <Mfullerton@biocuresolutions.com>, Debora Alexander <alexander.Deb@biocuresolutions.com>
Date: 2024-03-22

CALENDAR INVITE

You are invited to: Debora Alexander + Martin Fullerton Sync
Scheduled for: 2024-03-22

Organizer: Debora Alexander (alexander.Deb@biocuresolutions.com)

Attendees:
  - Martin Fullerton (Mfullerton@biocuresolutions.com)
  - Debora Alexander (alexander.Deb@biocuresolutions.com)

This meeting has been scheduled by Debora Alexander.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
