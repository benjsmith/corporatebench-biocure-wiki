---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_claudia_johnson_8a7e.txt
ingested_at: 2026-08-29T18:48:04.396732+00:00
sha256: 0f4e58ccc57ba2d51551754320b6a487f153e3055a77acc1b26525709262bed3
bytes: 2242
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Process Improvement Team Team Huddle

From: Claudia Johnson <Claud.j@biocuresolutions.com>
To: Noe Ortiz <nortiz@biocuresolutions.com>, Nancy Thompson <Ann.t@biocuresolutions.com>, Alexander Rice <Alec.r@biocuresolutions.com>, Nancy Thompson <Nthompson@biocuresolutions.com>, Anna Munson <Nanmunson@biocuresolutions.com>, George Salomonsson <Georgie_salomonsson@biocuresolutions.com>, Antonio Williams <Tony.williams@biocuresolutions.com>, Claudia Johnson <Claud.j@biocuresolutions.com>, Sandra Walker <Swalker@biocuresolutions.com>, Michelle Green <Mickey@biocuresolutions.com>, Michelle Green <Shellygreen@biocuresolutions.com>, Gary Tintzmann <garyt@biocuresolutions.com>, Michael Rohleder <Mikey.rohleder@biocuresolutions.com>, Nancy Thompson <Nannyt@biocuresolutions.com>, Paulina Morales <L.morales@biocuresolutions.com>, Brit Lee <britl@biocuresolutions.com>, Edeltrud Fullerton <edeltrudfullerton@biocuresolutions.com>, Mariechen Rice <mariechenrice@biocuresolutions.com>
Date: 2024-01-31

CALENDAR INVITE

You are invited to: Process Improvement Team Team Huddle
Scheduled for: 2024-01-31

Organizer: Claudia Johnson (Claud.j@biocuresolutions.com)

Attendees:
  - Noe Ortiz (nortiz@biocuresolutions.com)
  - Nancy Thompson (Ann.t@biocuresolutions.com)
  - Alexander Rice (Alec.r@biocuresolutions.com)
  - Nancy Thompson (Nthompson@biocuresolutions.com)
  - Anna Munson (Nanmunson@biocuresolutions.com)
  - George Salomonsson (Georgie_salomonsson@biocuresolutions.com)
  - Antonio Williams (Tony.williams@biocuresolutions.com)
  - Claudia Johnson (Claud.j@biocuresolutions.com)
  - Sandra Walker (Swalker@biocuresolutions.com)
  - Michelle Green (Mickey@biocuresolutions.com)
  - Michelle Green (Shellygreen@biocuresolutions.com)
  - Gary Tintzmann (garyt@biocuresolutions.com)
  - Michael Rohleder (Mikey.rohleder@biocuresolutions.com)
  - Nancy Thompson (Nannyt@biocuresolutions.com)
  - Paulina Morales (L.morales@biocuresolutions.com)
  - Brit Lee (britl@biocuresolutions.com)
  - Edeltrud Fullerton (edeltrudfullerton@biocuresolutions.com)
  - Mariechen Rice (mariechenrice@biocuresolutions.com)

This meeting has been scheduled by Claudia Johnson.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
