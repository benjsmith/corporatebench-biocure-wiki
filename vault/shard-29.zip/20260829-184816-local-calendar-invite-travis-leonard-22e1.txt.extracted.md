---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_travis_leonard_22e1.txt
ingested_at: 2026-08-29T18:48:16.622292+00:00
sha256: 8ac5c1b11d2a7d7b51b11f7015fb74ba3c27a0aeb4443570df5d553e7c087bc4
bytes: 3487
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team All-Hands

From: Travis Leonard <tleonard@biocuresolutions.com>
To: Diego Petty <dpetty@biocuresolutions.com>, Matheus Toussaint <matheustoussaint@biocuresolutions.com>, Federica Mason <fmason@biocuresolutions.com>, Antero Putz <anteroputz@biocuresolutions.com>, Rocco Lombardo <rocco.lombardo@biocuresolutions.com>, Patrik Vidal <patrik.v@biocuresolutions.com>, Angeles Abreu <aabreu@biocuresolutions.com>, Hannah Dominguez <Nan@biocuresolutions.com>, Sebastiano Trauner <trauner.sebastiano@biocuresolutions.com>, Patrick Momberg <Pmomberg@biocuresolutions.com>, Travis Leonard <tleonard@biocuresolutions.com>, Amalia Aumann <aumann.amalia@biocuresolutions.com>, Arthur Gabriel Noriega <Anoriega@biocuresolutions.com>, Sabina Dijkman <sabinadijkman@biocuresolutions.com>, Sofia Bah <sofiabah@biocuresolutions.com>, Siv Mares <siv.mares@biocuresolutions.com>, Mario Wohlgemut <m.wohlgemut@biocuresolutions.com>, Lesley Carli <Lcarli@biocuresolutions.com>, Gottfried Cartwright <gottfried.cartwright@biocuresolutions.com>, Rodney Hellberg <Rod.h@biocuresolutions.com>, Agatha Villalpando <Aga.v@biocuresolutions.com>, Rosalia Le <rosalia@biocuresolutions.com>, Eckhart Respighi <eckhart.respighi@biocuresolutions.com>, Rodrigo Sauvage <rodrigosauvage@biocuresolutions.com>, Steven Badillo <Sbadillo@biocuresolutions.com>, Orlando Pircher <Rolandp@biocuresolutions.com>, Shannon Figueiredo <shannon_figueiredo@biocuresolutions.com>, Vito Kennedy <vitok@biocuresolutions.com>, Ross Wahner <rwahner@biocuresolutions.com>, Jolie Edlund <jedlund@biocuresolutions.com>
Date: 2024-01-04

CALENDAR INVITE

You are invited to: Vendor Management Team All-Hands
Scheduled for: 2024-01-04

Organizer: Travis Leonard (tleonard@biocuresolutions.com)

Attendees:
  - Diego Petty (dpetty@biocuresolutions.com)
  - Matheus Toussaint (matheustoussaint@biocuresolutions.com)
  - Federica Mason (fmason@biocuresolutions.com)
  - Antero Putz (anteroputz@biocuresolutions.com)
  - Rocco Lombardo (rocco.lombardo@biocuresolutions.com)
  - Patrik Vidal (patrik.v@biocuresolutions.com)
  - Angeles Abreu (aabreu@biocuresolutions.com)
  - Hannah Dominguez (Nan@biocuresolutions.com)
  - Sebastiano Trauner (trauner.sebastiano@biocuresolutions.com)
  - Patrick Momberg (Pmomberg@biocuresolutions.com)
  - Travis Leonard (tleonard@biocuresolutions.com)
  - Amalia Aumann (aumann.amalia@biocuresolutions.com)
  - Arthur Gabriel Noriega (Anoriega@biocuresolutions.com)
  - Sabina Dijkman (sabinadijkman@biocuresolutions.com)
  - Sofia Bah (sofiabah@biocuresolutions.com)
  - Siv Mares (siv.mares@biocuresolutions.com)
  - Mario Wohlgemut (m.wohlgemut@biocuresolutions.com)
  - Lesley Carli (Lcarli@biocuresolutions.com)
  - Gottfried Cartwright (gottfried.cartwright@biocuresolutions.com)
  - Rodney Hellberg (Rod.h@biocuresolutions.com)
  - Agatha Villalpando (Aga.v@biocuresolutions.com)
  - Rosalia Le (rosalia@biocuresolutions.com)
  - Eckhart Respighi (eckhart.respighi@biocuresolutions.com)
  - Rodrigo Sauvage (rodrigosauvage@biocuresolutions.com)
  - Steven Badillo (Sbadillo@biocuresolutions.com)
  - Orlando Pircher (Rolandp@biocuresolutions.com)
  - Shannon Figueiredo (shannon_figueiredo@biocuresolutions.com)
  - Vito Kennedy (vitok@biocuresolutions.com)
  - Ross Wahner (rwahner@biocuresolutions.com)
  - Jolie Edlund (jedlund@biocuresolutions.com)

This meeting has been scheduled by Travis Leonard.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
