---
source_path: /workspace/corporatebench/biocure/documents/re_email_Exercise_integration_opportunities_d095.txt
ingested_at: 2026-08-29T18:53:26.082822+00:00
sha256: a16ef6be11ae91a7824ff4705259a60709af32873e6e5abebe7215868f2d4a56
bytes: 1727
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 7ac8bf2c-4bd7-4192-8e98-e705886557bc
From: Rocco Lombardo <rocco.lombardo@biocuresolutions.com>
To: Angeles Abreu <angeles.a@gmail.com>
Date: 2024-01-24
Subject: Re: Getting active on the commute
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Thank you for the update. I'll take it into consideration. See you soon!

Rocco Lombardo
Recruiter, BioCure Solutions

P: +1 (650) 919-9461
E: rocco.lombardo@biocuresolutions.com
[INSERT_HORIZONTAL_LOGO]

Thanks,
Rocco Lombardo


On 2024-01-23, Angeles Abreu wrote:
> Hey Rocco, so I've been thinking about how we spend so much time commuting every day, and I realized we're basically just sitting there doing nothing. I know a lot of folks on the team are looking to get more exercise in, and I figured why not use that commute time to actually do something productive for our health? Whether it's biking, walking, or even just parking further away - seems like a no-brainer to get some movement in.
> 
> I've been chatting with a few people around the office about ways we could make this more of a thing, and honestly, the response has been pretty cool. On another note, we're incorporating this into Vendor Management Team's annual plan, so I wanted to see if you'd be interested in helping me think through how we could encourage more people to try it out. It doesn't have to be complicated - just some simple ways to make the commute work double duty for both getting to work and staying fit.
> 
> Let me know if you're down to chat about this. I think it could be a solid way to get the team moving, literally. Could be fun to see who else wants to jump on board with the idea!
> 
> Thanks,
> Angeles Abreu
> Recruiter



<!-- END FETCHED CONTENT -->
