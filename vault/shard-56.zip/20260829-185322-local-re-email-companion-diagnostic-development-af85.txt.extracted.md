---
source_path: /workspace/corporatebench/biocure/documents/re_email_Companion_Diagnostic_Development_af85.txt
ingested_at: 2026-08-29T18:53:22.253591+00:00
sha256: b2eed52681adb830b523d5e333c47693429b8e84268dd14ee7e3587d0237fec4
bytes: 2186
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: b1720bd3-0aac-4181-8890-ff5c1d46a74d
From: Jason Moreira <jason@biocuresolutions.com>
To: Bjorn Fleury <bjorn.f@gmail.com>
Date: 2024-03-16
Subject: Re: Updates on our biomarker work and next steps
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Very interesting. I'd appreciate a chance to talk about it in person. See you soon!

Jason

Jason Moreira
Accountant, BioCure Solutions

P: +1 (650) 346-8135
E: jason@biocuresolutions.com
[INSERT_HORIZONTAL_LOGO]

Best,
Jason


On 2024-03-15, Bjorn Fleury wrote:
> Hi Jason, I wanted to touch base about where we're at with our companion diagnostic development initiatives. As we continue managing our drug development pipeline and the broader business operations side of things, I've been reflecting on how our biomarker identification strategy is shaping up. The work we're doing here feels really important, and I'm excited about the momentum we're building.
> 
> From a business operations perspective, we need to make sure we're optimizing our resource allocation across all these interconnected workstreams. Our drug development teams have been pushing hard on the biomarker identification front, which directly feeds into the companion diagnostic development phase. Related to this, analytical method compilation wrapped up, pivoting to what's next, and I think we're in a good position to accelerate our next phase of validation studies.
> 
> The analytical methods we've compiled are solid, and I believe they'll give us a strong foundation for moving forward with our diagnostic platform. I've been thinking about how we can streamline our approach and make sure we're capturing all the relevant data points we need for regulatory submissions. This connects to the bigger picture of where we want to position ourselves in the market with these companion diagnostics.
> 
> I'd love to sync up soon and walk through the technical details of what we're planning next. I think there's real potential here, and I'm keen to get your perspective on how we should prioritize our efforts moving forward.
> 
> Best regards,
> Bjorn
> 
> Bjorn Fleury
> Accountant | +1 (510) 198-4727



<!-- END FETCHED CONTENT -->
