---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_leila_williams_a7d0.txt
ingested_at: 2026-08-29T18:48:10.623331+00:00
sha256: 477fa400470ed247192f60adca0b5eea0ecae37b9215a25287b8de80783ff747
bytes: 637
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Task: pharmacokinetic dataset reconciliation

From: Leila Williams <lwilliams@biocuresolutions.com>
To: Leila Williams <lwilliams@biocuresolutions.com>, Susan Errigo <Susie.errigo@biocuresolutions.com>
Date: 2024-02-21

CALENDAR INVITE

You are invited to: Task: pharmacokinetic dataset reconciliation
Scheduled for: 2024-02-21

Organizer: Leila Williams (lwilliams@biocuresolutions.com)

Attendees:
  - Leila Williams (lwilliams@biocuresolutions.com)
  - Susan Errigo (Susie.errigo@biocuresolutions.com)

This meeting has been scheduled by Leila Williams.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
