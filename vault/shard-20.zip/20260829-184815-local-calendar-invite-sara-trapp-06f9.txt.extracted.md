---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sara_trapp_06f9.txt
ingested_at: 2026-08-29T18:48:15.216789+00:00
sha256: 0a45d724f34f2ef8dc4e7e542b2ac161c3edf4e415e7a455160ac2499aefc570
bytes: 1660
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Process Improvement Team Team Meeting

From: Sara Trapp <strapp@biocuresolutions.com>
To: Sara Trapp <strapp@biocuresolutions.com>, Klara Carneiro <kcarneiro@biocuresolutions.com>, Liana Marshall <l.marshall@biocuresolutions.com>, Frederik Doorhof <f.doorhof@biocuresolutions.com>, Harri Eichinger <heichinger@biocuresolutions.com>, Victoria Grant <Tgrant@biocuresolutions.com>, Adrien Cambier <acambier@biocuresolutions.com>, Ilija Sanchez <ilijasanchez@biocuresolutions.com>, Jamie Noel <James@biocuresolutions.com>, Isabella Doherty <Nibd@biocuresolutions.com>, Jean Devos <Janedevos@biocuresolutions.com>, Anne Berendse <Ann.b@biocuresolutions.com>, Lucie Saiz <saiz.lucie@biocuresolutions.com>
Date: 2024-02-02

CALENDAR INVITE

You are invited to: Process Improvement Team Team Meeting
Scheduled for: 2024-02-02

Organizer: Sara Trapp (strapp@biocuresolutions.com)

Attendees:
  - Sara Trapp (strapp@biocuresolutions.com)
  - Klara Carneiro (kcarneiro@biocuresolutions.com)
  - Liana Marshall (l.marshall@biocuresolutions.com)
  - Frederik Doorhof (f.doorhof@biocuresolutions.com)
  - Harri Eichinger (heichinger@biocuresolutions.com)
  - Victoria Grant (Tgrant@biocuresolutions.com)
  - Adrien Cambier (acambier@biocuresolutions.com)
  - Ilija Sanchez (ilijasanchez@biocuresolutions.com)
  - Jamie Noel (James@biocuresolutions.com)
  - Isabella Doherty (Nibd@biocuresolutions.com)
  - Jean Devos (Janedevos@biocuresolutions.com)
  - Anne Berendse (Ann.b@biocuresolutions.com)
  - Lucie Saiz (saiz.lucie@biocuresolutions.com)

This meeting has been scheduled by Sara Trapp.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
