---
source_path: /workspace/corporatebench/biocure/documents/email_Summer_activity_planning_ccc4.txt
ingested_at: 2026-08-29T18:52:14.769716+00:00
sha256: 4f573ed123085daa8bdbf6e79e0079e94f7f764aaa378ca90614c7e9c4c46f61
bytes: 1190
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: f47a06cc-42e0-4985-a49c-b228edbea009
From: Claudia Johnson <Claud.j@biocuresolutions.com>
To: Corey Kriegl <Rkriegl@gmail.com>
Date: 2024-02-25
Subject: Any fun plans for the summer?
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hey Corey, so I've been thinking about summer travel lately and figured I'd pick your brain. I know we're still in the thick of work stuff, but I've been daydreaming about getting away somewhere interesting once things settle down a bit. Are you planning anything seasonal this year, or just sticking around?

I've been trying to map out some activities I actually want to do instead of just winging it like I usually do. Related to this, I'm beginning my involvement with analytical method cross-validation, so I've been thinking analytically about how to structure my downtime better. Anyway, thought it might be nice to compare notes on what you're thinking for the season. Let me know if you've got any ideas!

Best,
Claudia Johnson
Research Scientist, Process Improvement Team
BioCure Solutions

+1 (650) 528-1265 | Claud.j@biocuresolutions.com
Office Hours: 9am - 6pm
https://calendly.com/claudj



<!-- END FETCHED CONTENT -->
