---
source_path: /workspace/corporatebench/biocure/documents/email_Toll_road_expenses_b13d.txt
ingested_at: 2026-08-29T18:52:29.505937+00:00
sha256: 7ef0f16d2115fde4ae7b218d7dda6a49012e1d6bad7ff1ba8735a0a57862b517
bytes: 1637
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: ad8db8d1-7768-4c75-867d-d67b80ea1d96
From: Marcelo Peronne <marcelo.peronne@gmail.com>
To: Trevor Karlstrom <trevor.karlstrom@gmail.com>
Date: 2024-03-28
Subject: Quick thought on commute expenses and our transportation costs
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Trevor, I wanted to touch base about something that came up during some casual conversation around the office the other day. We were talking about transportation costs and how they've been adding up for folks commuting to the lab sites, particularly around the toll road expenses that keep appearing on our expense reports. It's one of those things that doesn't get discussed much, but it does impact our budgets.

I've been thinking about how we might better track and manage these kinds of recurring transportation expenses, especially since several of us are spending considerable time traveling between our facilities. In the same vein, creating the pharmacokinetic-bioavailability integration documentation structure, which means we're going to have even more movement between locations over the next few weeks. This makes me think we should get ahead of the curve on documenting these costs properly.

Would you be open to grabbing coffee sometime to discuss how we're handling reimbursements for toll roads and travel? I'm curious about your experience with the current process and whether you think there's room for improvement. It seems like a straightforward conversation that could save everyone some headaches down the road.

Thank you,
Marcelo

Marcelo Peronne
Analyst
M: +1 (408) 833-4675



<!-- END FETCHED CONTENT -->
