---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_erica_pons_b616.txt
ingested_at: 2026-08-29T18:48:06.049237+00:00
sha256: ad210e1ba062ae3e7ff6678384439a6105d7ce402dec74cc0c7c2c335c29c7fd
bytes: 581
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Erica Pons <> Humberto Drake

From: Erica Pons <erica_pons@biocuresolutions.com>
To: Humberto Drake <hdrake@biocuresolutions.com>, Erica Pons <erica_pons@biocuresolutions.com>
Date: 2024-01-17

CALENDAR INVITE

You are invited to: Erica Pons <> Humberto Drake
Scheduled for: 2024-01-17

Organizer: Erica Pons (erica_pons@biocuresolutions.com)

Attendees:
  - Humberto Drake (hdrake@biocuresolutions.com)
  - Erica Pons (erica_pons@biocuresolutions.com)

This meeting has been scheduled by Erica Pons.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
