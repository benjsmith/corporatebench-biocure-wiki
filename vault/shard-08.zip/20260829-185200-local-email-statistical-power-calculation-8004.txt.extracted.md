---
source_path: /workspace/corporatebench/biocure/documents/email_Statistical_Power_Calculation_8004.txt
ingested_at: 2026-08-29T18:52:00.953551+00:00
sha256: 8e08a4d8fcd9e5d93234d497220e061c75cd49e41323526b33249290fc5f78ff
bytes: 1893
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 0502b244-42d0-4160-a0e9-0c9fdcdea433
From: Edith Sager <Edye@biocuresolutions.com>
To: Alec Huhn <alechuhn@biocuresolutions.com>
Date: 2024-03-30
Subject: Quick question on our trial planning metrics
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Alec,

I wanted to pick your brain about something that came up during our business operations review for the drug development side of things. We're deep in the clinical trial planning phase right now, and I'm realizing I need to get smarter about statistical power calculation before we move forward with our next phase. It's one of those things that feels super important but honestly kind of intimidating!

So here's my thing – I know statistical power calculation is basically about figuring out whether our study has enough sample size to detect a real effect, right? But I'm fuzzy on how we actually determine what power level we should be targeting and how that connects back to our overall trial design. Related to this, setting up Process Improvement Team's workflow applications, and I'm hoping that'll help me understand the workflows better so I can ask smarter questions moving forward.

I've been reading some basics about Type I and Type II errors, and I get that power is about minimizing Type II error, but I'm wondering how aggressive we typically go with our numbers on the drug development side. Do we usually aim for 80% power, 90%, something else? And how much does that decision impact our sample size requirements?

Would love to grab some time with you if you've got bandwidth – maybe you could walk me through how you all typically approach this on the Process Improvement Team side of things, or point me toward some good resources. Thanks so much!

Respectfully,
Edith Sager
Chemist, BioCure Solutions

P: +1 (415) 287-5691
E: Edye@biocuresolutions.com



<!-- END FETCHED CONTENT -->
