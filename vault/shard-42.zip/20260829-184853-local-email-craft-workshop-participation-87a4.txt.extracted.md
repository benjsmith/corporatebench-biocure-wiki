---
source_path: /workspace/corporatebench/biocure/documents/email_Craft_workshop_participation_87a4.txt
ingested_at: 2026-08-29T18:48:53.767678+00:00
sha256: 9a5c09f4d0ed988a5655e2df1a4228d9ea8464e5bd4b1dc89e0b4a88f933f0b7
bytes: 1224
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 42a368bf-b6b5-4ea2-ac65-8f25b6824408
From: Bethany Williams <williams.bethany@gmail.com>
To: Anna Munson <Nan@biocuresolutions.com>
Date: 2024-01-03
Subject: Thought you'd appreciate hearing about this workshop
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Anna, I wanted to share something I came across recently that I think you'd find interesting. I've been exploring some cultural experiences during my travels, and I stumbled upon this amazing craft workshop opportunity coming up next month. I work with Facilities Team and have insights to share, so I have some insights about logistics and space requirements that might be helpful if you're considering attending.

The workshop focuses on traditional pottery techniques and would be a wonderful way to unwind from work while learning something meaningful. I know you've mentioned wanting to try new things outside of the office, and this seemed like it could be a perfect fit. If you'd like more details about the schedule or what to bring, just let me know and I'd be happy to share what I've learned about it!

Best regards,
Bethany Williams

Bethany Williams
Compliance Specialist | BioCure Solutions



<!-- END FETCHED CONTENT -->
