---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sandro_grande_2674.txt
ingested_at: 2026-08-29T18:48:14.920459+00:00
sha256: a655d95854f2c837f05406ae8ef84a59ac6fc71fc5b4f078edd65c7054de1877
bytes: 616
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Sandro Grande + Lauren Magana Sync

From: Sandro Grande <sandrogrande@biocuresolutions.com>
To: Lauren Magana <Rmagana@biocuresolutions.com>, Sandro Grande <sandrogrande@biocuresolutions.com>
Date: 2024-01-17

CALENDAR INVITE

You are invited to: Sandro Grande + Lauren Magana Sync
Scheduled for: 2024-01-17

Organizer: Sandro Grande (sandrogrande@biocuresolutions.com)

Attendees:
  - Lauren Magana (Rmagana@biocuresolutions.com)
  - Sandro Grande (sandrogrande@biocuresolutions.com)

This meeting has been scheduled by Sandro Grande.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
