---
source_path: /workspace/corporatebench/biocure/documents/email_Statistical_Power_Calculation_c6c5.txt
ingested_at: 2026-08-29T18:52:01.980152+00:00
sha256: 3090be906afd0d9d751eb4f5d36d3846889d0191bc9a150e9171ab14dee865bb
bytes: 1636
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 8145982f-5695-4d5f-879c-e920bebcbdc7
From: Javier Borjesson <jborjesson@biocuresolutions.com>
To: Suus Desmet <suus@gmail.com>
Date: 2024-03-27
Subject: Quick question on statistical power for our trial design
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Suus, I wanted to pick your brain about something that's been coming up in our clinical trial planning discussions. We're working through the business operations side of how we structure our drug development timelines, and I realized I need to get clearer on the statistical power calculation piece.

Specifically, I'm trying to understand how we're determining our sample sizes and effect detection thresholds for the upcoming studies. The power calculation feels like it should tie directly into our pharmacokinetic data compilation efforts, right? Building on that,

I'm finishing up pharmacokinetic data compilation and transitioning off, so I'm thinking through how the statistical rigor we need might shift based on what we're seeing in the PK data.

I've got some preliminary numbers, but I want to make sure I'm not missing anything obvious about how we're setting our confidence intervals and alpha levels. It seems like this should be straightforward, but there's always some nuance depending on the trial design we're going with.

Would you have some time this week to walk through your approach? I'd rather get it right the first time than have to backtrack later.

Thank you,
Javier Borjesson
Analyst
BioCure Solutions

+1 (408) 743-6703 | jborjesson@biocuresolutions.com
www.linkedin.com/in/jborjesson92



<!-- END FETCHED CONTENT -->
