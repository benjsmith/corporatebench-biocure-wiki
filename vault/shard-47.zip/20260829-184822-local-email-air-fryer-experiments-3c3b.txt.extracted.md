---
source_path: /workspace/corporatebench/biocure/documents/email_Air_fryer_experiments_3c3b.txt
ingested_at: 2026-08-29T18:48:22.253923+00:00
sha256: 296956aec1ce2ac7ce8eed2b1c28dc6a0168a33a8d49ec187181539012a7959a
bytes: 1753
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 7a4cec1b-b0de-4f29-8391-222078d25e2a
From: Antonina Tschentscher <antonina.tschentscher@gmail.com>
To: Caroline Bustos <Cbustos@biocuresolutions.com>
Date: 2024-02-11
Subject: Quick chat about weekend kitchen adventures
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Carrie, hope you're having a good week! So I've been getting really into some casual food talk lately - you know how it is when you discover a new kitchen trend and suddenly you're obsessed with it. I picked up an air fryer a couple months ago and have been doing some pretty wild experiments with it, which has honestly been such a fun way to decompress after work.

I've tried everything from the obvious stuff like fries and chicken wings to some weirder combinations - roasted chickpeas with weird spice blends, even attempted air fryer donuts last weekend. The texture on certain foods is just different, you know? Anyway,

I'm working on a couple of things right now including creating the pharmacokinetic-metabolite concordance tracking board, so my personal projects might take a back seat for a bit, but I'm trying to keep the air fryer momentum going on weekends at least.

I'm actually compiling a list of my best recipes and failures if you want to swap ideas! There's something really satisfying about this whole trend - it feels less intimidating than traditional cooking but still gets you experimenting. Plus cleanup is way easier, which is honestly my favorite part.

Let me know if you've tried anything interesting lately or if you want to hear about my attempt at air fryer mozzarella sticks - spoiler alert: it was messy but delicious!

Respectfully,
Antonina Tschentscher
Recruiter
M: +1 (408) 991-1504



<!-- END FETCHED CONTENT -->
