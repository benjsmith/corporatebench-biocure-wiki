---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_armida_spreuwel_fe68.txt
ingested_at: 2026-08-29T18:48:03.237126+00:00
sha256: 75e22d96c0dcd730840425184732e2c126da4b2c8b658e38f35a90910761f38b
bytes: 670
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Armida Spreuwel <> Brandon Girschner

From: Armida Spreuwel <armida.spreuwel@biocuresolutions.com>
To: Brandon Girschner <brandon_girschner@biocuresolutions.com>, Armida Spreuwel <armida.spreuwel@biocuresolutions.com>
Date: 2024-03-04

CALENDAR INVITE

You are invited to: Armida Spreuwel <> Brandon Girschner
Scheduled for: 2024-03-04

Organizer: Armida Spreuwel (armida.spreuwel@biocuresolutions.com)

Attendees:
  - Brandon Girschner (brandon_girschner@biocuresolutions.com)
  - Armida Spreuwel (armida.spreuwel@biocuresolutions.com)

This meeting has been scheduled by Armida Spreuwel.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
