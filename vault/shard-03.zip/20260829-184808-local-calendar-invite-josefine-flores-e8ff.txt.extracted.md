---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_josefine_flores_e8ff.txt
ingested_at: 2026-08-29T18:48:08.934829+00:00
sha256: 2b5142fa49381bc925f6dd0dd1a80d3b1911e609be1d81e253df2da44ec37d18
bytes: 1654
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Standup

From: Josefine Flores <josefine.f@biocuresolutions.com>
To: Helen Ooms <Eooms@biocuresolutions.com>, Kevin Scamarcio <Kevscamarcio@biocuresolutions.com>, Ana Beatriz Alexander <aalexander@biocuresolutions.com>, Angela Travaglia <Angiet@biocuresolutions.com>, Josefine Flores <josefine.f@biocuresolutions.com>, Amanda Fernandez <Mfernandez@biocuresolutions.com>, Michael Marion <Mickey.marion@biocuresolutions.com>, Jessica Aranda <Jaranda@biocuresolutions.com>, Christine Smith <Csmith@biocuresolutions.com>, Nicholas Hamilton <Nickie@biocuresolutions.com>, Phillip Fullerton <fullerton.Pip@biocuresolutions.com>, Timothy Guerin <guerin.Tim@biocuresolutions.com>
Date: 2024-03-01

CALENDAR INVITE

You are invited to: Vendor Management Team Standup
Scheduled for: 2024-03-01

Organizer: Josefine Flores (josefine.f@biocuresolutions.com)

Attendees:
  - Helen Ooms (Eooms@biocuresolutions.com)
  - Kevin Scamarcio (Kevscamarcio@biocuresolutions.com)
  - Ana Beatriz Alexander (aalexander@biocuresolutions.com)
  - Angela Travaglia (Angiet@biocuresolutions.com)
  - Josefine Flores (josefine.f@biocuresolutions.com)
  - Amanda Fernandez (Mfernandez@biocuresolutions.com)
  - Michael Marion (Mickey.marion@biocuresolutions.com)
  - Jessica Aranda (Jaranda@biocuresolutions.com)
  - Christine Smith (Csmith@biocuresolutions.com)
  - Nicholas Hamilton (Nickie@biocuresolutions.com)
  - Phillip Fullerton (fullerton.Pip@biocuresolutions.com)
  - Timothy Guerin (guerin.Tim@biocuresolutions.com)

This meeting has been scheduled by Josefine Flores.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
