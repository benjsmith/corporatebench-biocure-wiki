---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_raul_rossello_f6e7.txt
ingested_at: 2026-08-29T18:48:13.592004+00:00
sha256: 9cdfa194b1c6311d914e64b76c5ff1f49e09a9b2f3c6362671ba81797640ad71
bytes: 596
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Amanda Schaaf <> Raul Rossello

From: Raul Rossello <rrossello@biocuresolutions.com>
To: Raul Rossello <rrossello@biocuresolutions.com>, Amanda Schaaf <Mschaaf@biocuresolutions.com>
Date: 2024-01-16

CALENDAR INVITE

You are invited to: Amanda Schaaf <> Raul Rossello
Scheduled for: 2024-01-16

Organizer: Raul Rossello (rrossello@biocuresolutions.com)

Attendees:
  - Raul Rossello (rrossello@biocuresolutions.com)
  - Amanda Schaaf (Mschaaf@biocuresolutions.com)

This meeting has been scheduled by Raul Rossello.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
