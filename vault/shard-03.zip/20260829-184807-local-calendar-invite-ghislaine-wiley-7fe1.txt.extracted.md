---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_ghislaine_wiley_7fe1.txt
ingested_at: 2026-08-29T18:48:07.833134+00:00
sha256: cab2678251292d136ab656a0bdc92f52950a04d9b3522b6070fcab81ad554775
bytes: 2363
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Standup

From: Ghislaine Wiley <g.wiley@biocuresolutions.com>
To: Mariane Gruil <mariane.g@biocuresolutions.com>, Constanze Nascimento <constanze@biocuresolutions.com>, Brad Faria <faria.Ford@biocuresolutions.com>, Salome Berg <Loomie@biocuresolutions.com>, Baldassare Duivenvoorden <baldassare_duivenvoorden@biocuresolutions.com>, Magdalena Cisneros <Maggie@biocuresolutions.com>, Bernardo Fonseca <b.fonseca@biocuresolutions.com>, Billy Christian <Fred_christian@biocuresolutions.com>, Ruth Valente <ruth@biocuresolutions.com>, Deanna Mclean <deanna@biocuresolutions.com>, Kimberley Lemaitre <Kim.l@biocuresolutions.com>, Ghislaine Wiley <g.wiley@biocuresolutions.com>, Genevieve Zedillo <Evezedillo@biocuresolutions.com>, Luuk Klasson <luuk_klasson@biocuresolutions.com>, Reina Azcona <reinaazcona@biocuresolutions.com>, Heather Riviere <H.riviere@biocuresolutions.com>, Arnulfo Assuncao <arnulfoa@biocuresolutions.com>, Henrik Nolan <hnolan@biocuresolutions.com>, Karl Pimenta <karlpimenta@biocuresolutions.com>
Date: 2024-02-05

CALENDAR INVITE

You are invited to: Vendor Management Team Standup
Scheduled for: 2024-02-05

Organizer: Ghislaine Wiley (g.wiley@biocuresolutions.com)

Attendees:
  - Mariane Gruil (mariane.g@biocuresolutions.com)
  - Constanze Nascimento (constanze@biocuresolutions.com)
  - Brad Faria (faria.Ford@biocuresolutions.com)
  - Salome Berg (Loomie@biocuresolutions.com)
  - Baldassare Duivenvoorden (baldassare_duivenvoorden@biocuresolutions.com)
  - Magdalena Cisneros (Maggie@biocuresolutions.com)
  - Bernardo Fonseca (b.fonseca@biocuresolutions.com)
  - Billy Christian (Fred_christian@biocuresolutions.com)
  - Ruth Valente (ruth@biocuresolutions.com)
  - Deanna Mclean (deanna@biocuresolutions.com)
  - Kimberley Lemaitre (Kim.l@biocuresolutions.com)
  - Ghislaine Wiley (g.wiley@biocuresolutions.com)
  - Genevieve Zedillo (Evezedillo@biocuresolutions.com)
  - Luuk Klasson (luuk_klasson@biocuresolutions.com)
  - Reina Azcona (reinaazcona@biocuresolutions.com)
  - Heather Riviere (H.riviere@biocuresolutions.com)
  - Arnulfo Assuncao (arnulfoa@biocuresolutions.com)
  - Henrik Nolan (hnolan@biocuresolutions.com)
  - Karl Pimenta (karlpimenta@biocuresolutions.com)

This meeting has been scheduled by Ghislaine Wiley.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
