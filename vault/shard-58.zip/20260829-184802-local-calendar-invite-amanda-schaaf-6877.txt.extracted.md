---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_amanda_schaaf_6877.txt
ingested_at: 2026-08-29T18:48:02.186923+00:00
sha256: 6c764dca4405a0b9775c244169c957e9a37ac5d2efed92b73ca41db7a2482543
bytes: 2212
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Standup

From: Amanda Schaaf <Mschaaf@biocuresolutions.com>
To: Angela Fry <Afry@biocuresolutions.com>, Samuel Amorim <Sammy@biocuresolutions.com>, Eva Roberts <E.roberts@biocuresolutions.com>, Scott Williams <williams.Squat@biocuresolutions.com>, Laura Seiwald <seiwald.laura@biocuresolutions.com>, Charles Garcia <Chuck_garcia@biocuresolutions.com>, Jesus Ortiz <jesuso@biocuresolutions.com>, Edward Marec <Teddymarec@biocuresolutions.com>, Laura Janssens <laura_janssens@biocuresolutions.com>, Chris Murphy <Krism@biocuresolutions.com>, Thomas Pedersoli <Tom.pedersoli@biocuresolutions.com>, Thierry Martin <thierrym@biocuresolutions.com>, Amanda Schaaf <Mschaaf@biocuresolutions.com>, Robert Jesus <Rjesus@biocuresolutions.com>, George Fibonacci <Georgie@biocuresolutions.com>, Joao Lucas Ortiz <joao.ortiz@biocuresolutions.com>, Samuel Trubin <Sammytrubin@biocuresolutions.com>, Bernhard Thompson <bernhard.thompson@biocuresolutions.com>
Date: 2024-03-04

CALENDAR INVITE

You are invited to: Vendor Management Team Standup
Scheduled for: 2024-03-04

Organizer: Amanda Schaaf (Mschaaf@biocuresolutions.com)

Attendees:
  - Angela Fry (Afry@biocuresolutions.com)
  - Samuel Amorim (Sammy@biocuresolutions.com)
  - Eva Roberts (E.roberts@biocuresolutions.com)
  - Scott Williams (williams.Squat@biocuresolutions.com)
  - Laura Seiwald (seiwald.laura@biocuresolutions.com)
  - Charles Garcia (Chuck_garcia@biocuresolutions.com)
  - Jesus Ortiz (jesuso@biocuresolutions.com)
  - Edward Marec (Teddymarec@biocuresolutions.com)
  - Laura Janssens (laura_janssens@biocuresolutions.com)
  - Chris Murphy (Krism@biocuresolutions.com)
  - Thomas Pedersoli (Tom.pedersoli@biocuresolutions.com)
  - Thierry Martin (thierrym@biocuresolutions.com)
  - Amanda Schaaf (Mschaaf@biocuresolutions.com)
  - Robert Jesus (Rjesus@biocuresolutions.com)
  - George Fibonacci (Georgie@biocuresolutions.com)
  - Joao Lucas Ortiz (joao.ortiz@biocuresolutions.com)
  - Samuel Trubin (Sammytrubin@biocuresolutions.com)
  - Bernhard Thompson (bernhard.thompson@biocuresolutions.com)

This meeting has been scheduled by Amanda Schaaf.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
