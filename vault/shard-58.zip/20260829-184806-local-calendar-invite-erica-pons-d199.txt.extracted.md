---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_erica_pons_d199.txt
ingested_at: 2026-08-29T18:48:06.068092+00:00
sha256: 94086f1c651cc571eb47abb101f29b5348e8abe8fcb4b4811cd1c111a5ac6b94
bytes: 2062
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Business Operations Team Sync

From: Erica Pons <erica_pons@biocuresolutions.com>
To: Rickey Ritter <rritter@biocuresolutions.com>, Regulo Gray <rgray@biocuresolutions.com>, Suus Desmet <sdesmet@biocuresolutions.com>, Humberto Drake <hdrake@biocuresolutions.com>, Faith Lehner <lehner.Fay@biocuresolutions.com>, Traugott May <traugott@biocuresolutions.com>, Rosemary Watkins <Marie_watkins@biocuresolutions.com>, Erica Pons <erica_pons@biocuresolutions.com>, Arturo Nuwenhuysen <arturo@biocuresolutions.com>, Rocio Maldonado <maldonado.rocio@biocuresolutions.com>, Philippine Blondel <philippine@biocuresolutions.com>, Rene Cespedes <rcespedes@biocuresolutions.com>, Shawn Correia <Scorreia@biocuresolutions.com>, Tamara Leao <tleao@biocuresolutions.com>, Tammy Doyle <Tammied@biocuresolutions.com>, Ethan Hansson <ethanhansson@biocuresolutions.com>, Dino Gordon <dgordon@biocuresolutions.com>
Date: 2024-01-02

CALENDAR INVITE

You are invited to: Business Operations Team Sync
Scheduled for: 2024-01-02

Organizer: Erica Pons (erica_pons@biocuresolutions.com)

Attendees:
  - Rickey Ritter (rritter@biocuresolutions.com)
  - Regulo Gray (rgray@biocuresolutions.com)
  - Suus Desmet (sdesmet@biocuresolutions.com)
  - Humberto Drake (hdrake@biocuresolutions.com)
  - Faith Lehner (lehner.Fay@biocuresolutions.com)
  - Traugott May (traugott@biocuresolutions.com)
  - Rosemary Watkins (Marie_watkins@biocuresolutions.com)
  - Erica Pons (erica_pons@biocuresolutions.com)
  - Arturo Nuwenhuysen (arturo@biocuresolutions.com)
  - Rocio Maldonado (maldonado.rocio@biocuresolutions.com)
  - Philippine Blondel (philippine@biocuresolutions.com)
  - Rene Cespedes (rcespedes@biocuresolutions.com)
  - Shawn Correia (Scorreia@biocuresolutions.com)
  - Tamara Leao (tleao@biocuresolutions.com)
  - Tammy Doyle (Tammied@biocuresolutions.com)
  - Ethan Hansson (ethanhansson@biocuresolutions.com)
  - Dino Gordon (dgordon@biocuresolutions.com)

This meeting has been scheduled by Erica Pons.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
