---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_heinz-gunter_harper_a95c.txt
ingested_at: 2026-08-29T18:48:08.031434+00:00
sha256: 63500f12fe5b13b3d263d59dfd13a4cbc36b7ef98e5258098a7b66f111e0ab05
bytes: 674
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Task: hepatic metabolism pathway reconciliation

From: Heinz-Gunter Harper <heinz-gunter@biocuresolutions.com>
To: Nicole Hale <Nicky_hale@biocuresolutions.com>, Heinz-Gunter Harper <heinz-gunter@biocuresolutions.com>
Date: 2024-01-25

CALENDAR INVITE

You are invited to: Task: hepatic metabolism pathway reconciliation
Scheduled for: 2024-01-25

Organizer: Heinz-Gunter Harper (heinz-gunter@biocuresolutions.com)

Attendees:
  - Nicole Hale (Nicky_hale@biocuresolutions.com)
  - Heinz-Gunter Harper (heinz-gunter@biocuresolutions.com)

This meeting has been scheduled by Heinz-Gunter Harper.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
