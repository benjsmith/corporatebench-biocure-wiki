---
source_path: /workspace/corporatebench/biocure/documents/agenda_Project_Kickoff_and_Scope_Definition_dac2.txt
ingested_at: 2026-08-29T18:47:57.934466+00:00
sha256: e93b252ff791c2d47b26649b7bdc982e425f8ee11a565a53950ad56d3d3c4b0d
bytes: 3209
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: e2c52dc9-6600-43ae-8afc-f940795bc6dc
From: Erik Heijmen <erikh@biocuresolutions.com>
To: Rhys Stokes <rstokes@biocuresolutions.com>, Fiene Kjellberg <fkjellberg@biocuresolutions.com>, Serafina Peters <serafina.peters@biocuresolutions.com>, Mateus Kent <mateus.k@biocuresolutions.com>, Anastasie Whitney <awhitney@biocuresolutions.com>, Ake Sordi <asordi@biocuresolutions.com>, Nanni Groen <nanni@biocuresolutions.com>, Matteo Nogueira <m.nogueira@biocuresolutions.com>, Shelley Schacht <shelley_schacht@biocuresolutions.com>, Ivonne Cammel <icammel@biocuresolutions.com>, Hugo Charrier <hcharrier@biocuresolutions.com>
Date: 2024-01-05
Subject: Pharmacokinetics Research Manuscript Development & Journal Submission Pipeline Project Meeting
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hey Rhys, Fiene Kjellberg, Serafina Peters, Mateus Kent, Anastasie Whitney, Ake, Nanni, Matteo Nogueira, Shelley Schacht, Ivonne, and Hugo Charrier,

We've got some solid momentum building on the Pharmacokinetics Research Manuscript Development & Journal Submission Pipeline project, and I wanted to get everyone aligned on where we stand and what we need to tackle together. Quick update on where things stand:

1) I started the preview phase for assay protocol development
2) Fiene Kjellberg is well into clinical trial protocol review, approximately 72% finished
3) Ake Sordi is sketching out the roadmap for bioavailability data integration
4) Anastasie Whitney and Rhys Stokes have the initial groundwork complete for solubility data integration, about 24% finished
5) Matteo has the opening deliverables ready for compound screening data compilation
6) Solubility parameter documentation is gaining traction with Serafina Peters, roughly 41% complete
7) Mateus Kent is planning the solubility data integration workflow
8) We're building the Pharmacokinetics Research Manuscript Development & Journal Submission Pipeline work breakdown structure and assigning ownership for each component

Now that we've got a clearer picture of progress across all workstreams, we really need to nail down the scope definition and make sure everyone's crystal clear on how these pieces fit together. During our meeting, we'll be walking through the work breakdown structure we're building and confirming ownership for each component so there's no confusion about who's responsible for what. We should also talk about any dependencies between compound screening data compilation, clinical trial protocol review, bioavailability data integration, solubility data integration, assay protocol development, and solubility parameter documentation to make sure we're not creating bottlenecks.

Please come ready to discuss your specific workstreams, any blockers you're running into, and what support you might need from the team to keep things moving forward. This meeting is really about making sure we're all rowing in the same direction and that our timelines are realistic given what's already in progress.

Respectfully,
Erik

Erik Heijmen
Content Writer
Facilities Team, Strategic Communications & Marketing
BioCure Solutions

+1 (408) 712-8335 | erikh@biocuresolutions.com



<!-- END FETCHED CONTENT -->
