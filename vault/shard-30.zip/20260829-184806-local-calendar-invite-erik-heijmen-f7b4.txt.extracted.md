---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_erik_heijmen_f7b4.txt
ingested_at: 2026-08-29T18:48:06.120592+00:00
sha256: 437dd49960016e2eadff6c1c08753d74c7bc3357308f363e1189c04bef98d320
bytes: 595
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Erik Heijmen <> Matteo Nogueira 1:1

From: Erik Heijmen <erikh@biocuresolutions.com>
To: Erik Heijmen <erikh@biocuresolutions.com>, Matteo Nogueira <m.nogueira@biocuresolutions.com>
Date: 2024-03-22

CALENDAR INVITE

You are invited to: Erik Heijmen <> Matteo Nogueira 1:1
Scheduled for: 2024-03-22

Organizer: Erik Heijmen (erikh@biocuresolutions.com)

Attendees:
  - Erik Heijmen (erikh@biocuresolutions.com)
  - Matteo Nogueira (m.nogueira@biocuresolutions.com)

This meeting has been scheduled by Erik Heijmen.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
