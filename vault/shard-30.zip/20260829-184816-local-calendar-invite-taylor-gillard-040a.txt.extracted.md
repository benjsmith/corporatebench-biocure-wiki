---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_taylor_gillard_040a.txt
ingested_at: 2026-08-29T18:48:16.188758+00:00
sha256: fa9db79a35ba6cf1e418e4a1d6aa4eea28d66cdc9169dc77258e194ed6b4ee9f
bytes: 593
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Edouard Simon <> Taylor Gillard

From: Taylor Gillard <taylorg@biocuresolutions.com>
To: Taylor Gillard <taylorg@biocuresolutions.com>, Edouard Simon <esimon@biocuresolutions.com>
Date: 2024-01-03

CALENDAR INVITE

You are invited to: Edouard Simon <> Taylor Gillard
Scheduled for: 2024-01-03

Organizer: Taylor Gillard (taylorg@biocuresolutions.com)

Attendees:
  - Taylor Gillard (taylorg@biocuresolutions.com)
  - Edouard Simon (esimon@biocuresolutions.com)

This meeting has been scheduled by Taylor Gillard.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
