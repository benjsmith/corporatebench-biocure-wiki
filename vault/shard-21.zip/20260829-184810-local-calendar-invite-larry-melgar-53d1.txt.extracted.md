---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_larry_melgar_53d1.txt
ingested_at: 2026-08-29T18:48:10.434026+00:00
sha256: 86b244279cee4d5f84e34cf8fb7d3bc2e19a21198ae0d7c33c0f5b06c535206c
bytes: 637
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Jeffrey Woodward <> Larry Melgar 1:1

From: Larry Melgar <Lawrence_melgar@biocuresolutions.com>
To: Jeffrey Woodward <Gwoodward@biocuresolutions.com>, Larry Melgar <Lawrence_melgar@biocuresolutions.com>
Date: 2024-03-01

CALENDAR INVITE

You are invited to: Jeffrey Woodward <> Larry Melgar 1:1
Scheduled for: 2024-03-01

Organizer: Larry Melgar (Lawrence_melgar@biocuresolutions.com)

Attendees:
  - Jeffrey Woodward (Gwoodward@biocuresolutions.com)
  - Larry Melgar (Lawrence_melgar@biocuresolutions.com)

This meeting has been scheduled by Larry Melgar.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
