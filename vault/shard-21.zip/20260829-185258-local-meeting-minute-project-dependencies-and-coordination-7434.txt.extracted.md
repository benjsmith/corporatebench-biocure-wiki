---
source_path: /workspace/corporatebench/biocure/documents/meeting_minute_Project_Dependencies_and_Coordination_7434.txt
ingested_at: 2026-08-29T18:52:58.809344+00:00
sha256: d8ef26e38b41216e81cc3107daa3a5ee1202caf97680876af7273abd20351fa9
bytes: 3471
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 2d49fb10-8627-4269-bbe5-35c65b7fd483
From: William Bertho <Willbertho@biocuresolutions.com>
To: Pilar Costa <costa.pilar@biocuresolutions.com>, Miguel Evrard <Miguaill.evrard@biocuresolutions.com>, Freddy Black <freddyblack@biocuresolutions.com>, William Schweinfurt <Bill@biocuresolutions.com>, Alicia Meza <Lmeza@biocuresolutions.com>, Corona Ekberg <corona.e@biocuresolutions.com>, Daniela Gillet <daniela_gillet@biocuresolutions.com>, Immo Mcclain <i.mcclain@biocuresolutions.com>, Mikael Herve <mikael@biocuresolutions.com>, Chloe Adams <Cloa@biocuresolutions.com>, Xavier Munoz <xavier_munoz@biocuresolutions.com>, Simona Leyva <s.leyva@biocuresolutions.com>, Casey Pires <K.c.pires@biocuresolutions.com>, Luana Luna <luanal@biocuresolutions.com>, Brenda Nevado <nevado.Brandy@biocuresolutions.com>, Jade Bowen <jade@biocuresolutions.com>
Date: 2024-03-15
Subject: Phase IIb Hypertension Trial Protocol Amendment & EMA Submission Package Review
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Pilar, Miguaill, Freddy Black, Bill, Alicia Meza, Corona Ekberg, Daniela, Immo Mcclain, Mikael, Chloe, Xavier Munoz, Simona Leyva, K.c., Luana, Brenda, and Jade,

Thanks everyone for joining us today to review where we stand on the Phase IIb Hypertension Trial Protocol Amendment and our EMA Submission Package. We spent a good chunk of time walking through the current state of our deliverables and making sure all the dependencies are clear across workstreams. The team needs to be really coordinated here since we're in the home stretch and timing is critical for our submission timeline.

We talked through several key coordination points, particularly around how stability data compilation feeds into the final submission package and what that means for parallel workstreams. Everyone's clear on their ownership of specific sections and we identified a few handoff points that need tight communication moving forward. I'll be sending out detailed action items separately, but wanted to make sure the whole team has visibility into where we actually are with things.

Here's where we stand on our key milestones:

- Stability data compilation is in the final stretch with Miguel Evrard, roughly 80% done
- Phase IIb Hypertension Trial Protocol Amendment & EMA Submission Package is approaching completion, around 90% there

Given how close we're getting to completion on both fronts, staying tightly coordinated over the next phase is going to make or break our timeline. I'm counting on everyone to flag any blockers early and keep communication tight with your counterparts on other workstreams. Let me know if you need any clarification on the action items or dependencies.

Thanks,
William Bertho
Clinical Coordinator | Vendor Management Team
BioCure Solutions

P: +1 (415) 713-5722
E: Willbertho@biocuresolutions.com
[INSERT_BOX_LOGO]



--------------------------------------------------
CONFIDENTIALITY NOTICE: This email, including any attachments, is intended only for the recipient(s) named above and may contain privileged, confidential, or otherwise protected information. If you are not the intended recipient, you are hereby notified that any review, dissemination, distribution, or duplication of this communication is strictly prohibited. If you received this email in error, please notify the sender and delete this message from your system.
--------------------------------------------------

<!-- END FETCHED CONTENT -->
