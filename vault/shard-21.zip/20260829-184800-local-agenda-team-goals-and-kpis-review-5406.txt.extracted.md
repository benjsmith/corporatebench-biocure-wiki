---
source_path: /workspace/corporatebench/biocure/documents/agenda_Team_Goals_and_KPIs_Review_5406.txt
ingested_at: 2026-08-29T18:48:00.316328+00:00
sha256: 01d0455b167fa0278809f6b7c8673a13074a44a7d21c7f58923d2c79586ba9ef
bytes: 3684
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: b381f180-826b-41c8-a11a-4c6c61770f9e
From: Oliver Peterson <Opeterson@biocuresolutions.com>
To: Sharon Morales <Shay_morales@biocuresolutions.com>, Megan Ortiz <M.ortiz@biocuresolutions.com>, Carolyn Spence <spence.Lynn@biocuresolutions.com>, Sarah Almeida <Sally.almeida@biocuresolutions.com>, Lorraine Rice <Lrice@biocuresolutions.com>, Richard Krall <Dickie.krall@biocuresolutions.com>, Christopher Schofield <Kit.s@biocuresolutions.com>, Rachel Collins <collins.Shelly@biocuresolutions.com>, Amy Moore <amoore@biocuresolutions.com>, Alara Lopez <a.lopez@biocuresolutions.com>, Robert Dupont <Bobd@biocuresolutions.com>, Sandra Walker <Sandy.w@biocuresolutions.com>, Nancy Thompson <Nthompson@biocuresolutions.com>, Jillian Murphy <Jillm@biocuresolutions.com>, Samuel Cignaroli <Scignaroli@biocuresolutions.com>, Jessica Salinas <Jessies@biocuresolutions.com>, Severine Flores <sflores@biocuresolutions.com>, Tracy Rice <rice.tracy@biocuresolutions.com>, Joseph Castello <Jody@biocuresolutions.com>, Kevin Bruggeman <Kev.bruggeman@biocuresolutions.com>
Date: 2024-02-05
Subject: Facilities Team All-Hands
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi everyone,

I'm reaching out to let you know we've got our Facilities Team all-hands coming up, and I wanted to get everyone prepped on what we'll be covering. This is a good opportunity for us to take a step back and review where our team stands on our goals and KPIs, make sure we're aligned on what matters most, and talk through any blockers we're running into. I'd like us to come ready to share updates from our respective areas so we can get a full picture of our collective progress.

Here's what we'll be working through together:

Sarah Almeida is making early headway on metabolite elimination profiling, approximately 18% complete. Sally is well into metabolite toxicity assessment, approximately 72% finished. Sharon Morales has the baseline metabolite hazard classification materials complete. Sharon Morales obtained necessary licenses for absorption kinetics data integration. Metabolite pathway mapping is nearly across the finish line with Tracy Rice, approximately 86% complete. Bioavailability-clearance integration has commenced with Rachel Collins, around 14% accomplished. Carolyn and Megan are about 30-40% of the way through metabolite safety integration. Carolyn Spence circulated the metabolite quantitation assay development announcement to all departments. Kit is installing required equipment for metabolite hazard classification review. Megan is setting up the workspace for plasma protein binding validation. Lorraine conducted a preliminary analysis for metabolite clearance pathway documentation. Lorraine is roughly a third done with metabolite bioanalytical validation. Dickie has a good chunk of metabolite safety profile consolidation done, about 30-45%. Hepatic metabolism data integration is still in early stages with Amy and Robert, around 15-25% complete. I am wrapping up the last pieces of metabolite bioanalytical validation, approximately 88% complete.

As we head into this meeting, I think it'll be really valuable for us to discuss how we're tracking against our targets, celebrate what's working well, and identify where we might need to adjust our approach. It's also a chance to make sure we're supporting each other and that everyone has what they need to keep moving forward. Looking forward to catching up with the whole team.

Thanks,
Oliver Peterson
Research Scientist, Facilities Team
BioCure Solutions

+1 (510) 608-5524 | Opeterson@biocuresolutions.com
Office Hours: 9am - 6pm
https://calendly.com/opeterson



<!-- END FETCHED CONTENT -->
