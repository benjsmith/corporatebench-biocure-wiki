---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_ruben_sieberer_20f1.txt
ingested_at: 2026-08-29T18:48:14.002668+00:00
sha256: e7e234ade6d04dd02f32f75a435d34f6bdb30c308525b92e6c356af4c44f7050
bytes: 617
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Ruben Sieberer <> Darryl Boyer

From: Ruben Sieberer <sieberer.ruben@biocuresolutions.com>
To: Darryl Boyer <dboyer@biocuresolutions.com>, Ruben Sieberer <sieberer.ruben@biocuresolutions.com>
Date: 2024-01-09

CALENDAR INVITE

You are invited to: Ruben Sieberer <> Darryl Boyer
Scheduled for: 2024-01-09

Organizer: Ruben Sieberer (sieberer.ruben@biocuresolutions.com)

Attendees:
  - Darryl Boyer (dboyer@biocuresolutions.com)
  - Ruben Sieberer (sieberer.ruben@biocuresolutions.com)

This meeting has been scheduled by Ruben Sieberer.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
