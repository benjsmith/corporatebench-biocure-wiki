---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_daniel_ledoux_e656.txt
ingested_at: 2026-08-29T18:48:04.968018+00:00
sha256: 3d41f64f9a517323e643cc27fce0b92f48ffbf2470ca61a28e7e14756790dda2
bytes: 2024
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Sync

From: Daniel Ledoux <Dan@biocuresolutions.com>
To: Britt Arias <brittarias@biocuresolutions.com>, Patricia Jacquet <Tjacquet@biocuresolutions.com>, Shelby Livingston <slivingston@biocuresolutions.com>, Kevin Abatantuono <Kev@biocuresolutions.com>, Daniel Ledoux <Dan@biocuresolutions.com>, Linda Groth <L.groth@biocuresolutions.com>, Nikolina Leal <nikolina.leal@biocuresolutions.com>, Emily Molesini <Em_molesini@biocuresolutions.com>, Pierangelo Hammarstrom <hammarstrom.pierangelo@biocuresolutions.com>, Daniel Powell <Danny.powell@biocuresolutions.com>, Jessica Bjorklund <Jess.b@biocuresolutions.com>, Guilherme Bjork <guilherme_bjork@biocuresolutions.com>, Solange Hurst <solange.h@biocuresolutions.com>, Alain Adam <alain_adam@biocuresolutions.com>, Mauro Serrano <mauro@biocuresolutions.com>, Susan Wang <Hannahwang@biocuresolutions.com>
Date: 2024-03-01

CALENDAR INVITE

You are invited to: Vendor Management Team Sync
Scheduled for: 2024-03-01

Organizer: Daniel Ledoux (Dan@biocuresolutions.com)

Attendees:
  - Britt Arias (brittarias@biocuresolutions.com)
  - Patricia Jacquet (Tjacquet@biocuresolutions.com)
  - Shelby Livingston (slivingston@biocuresolutions.com)
  - Kevin Abatantuono (Kev@biocuresolutions.com)
  - Daniel Ledoux (Dan@biocuresolutions.com)
  - Linda Groth (L.groth@biocuresolutions.com)
  - Nikolina Leal (nikolina.leal@biocuresolutions.com)
  - Emily Molesini (Em_molesini@biocuresolutions.com)
  - Pierangelo Hammarstrom (hammarstrom.pierangelo@biocuresolutions.com)
  - Daniel Powell (Danny.powell@biocuresolutions.com)
  - Jessica Bjorklund (Jess.b@biocuresolutions.com)
  - Guilherme Bjork (guilherme_bjork@biocuresolutions.com)
  - Solange Hurst (solange.h@biocuresolutions.com)
  - Alain Adam (alain_adam@biocuresolutions.com)
  - Mauro Serrano (mauro@biocuresolutions.com)
  - Susan Wang (Hannahwang@biocuresolutions.com)

This meeting has been scheduled by Daniel Ledoux.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
