---
source_path: /workspace/corporatebench/biocure/documents/agenda_Project_Retrospective_and_Lessons_Learned_3a41.txt
ingested_at: 2026-08-29T18:47:57.965185+00:00
sha256: db582e8a91c7a2b58bb2168f1d5629ea78355c96a49d9d30ca3c45bd29c40e1a
bytes: 3183
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 733de809-a336-47e5-9501-87dc7d1a8455
From: William Bertho <Willbertho@biocuresolutions.com>
To: Pilar Costa <costa.pilar@biocuresolutions.com>, Miguel Evrard <Miguaill.evrard@biocuresolutions.com>, Freddy Black <freddyblack@biocuresolutions.com>, William Schweinfurt <Bill@biocuresolutions.com>, Alicia Meza <Lmeza@biocuresolutions.com>, Corona Ekberg <corona.e@biocuresolutions.com>, Daniela Gillet <daniela_gillet@biocuresolutions.com>, Immo Mcclain <i.mcclain@biocuresolutions.com>, Mikael Herve <mikael@biocuresolutions.com>, Simona Leyva <s.leyva@biocuresolutions.com>, Rik Curtis <curtis.rik@biocuresolutions.com>, Afonso Nelson <afonso.n@biocuresolutions.com>, Rosario Salet <salet.rosario@biocuresolutions.com>, Caterina Jacobs <caterina.jacobs@biocuresolutions.com>, Kevim Giradello <kevimgiradello@biocuresolutions.com>, Hadassa Coelho <hadassa.coelho@biocuresolutions.com>, Ian Cardano <John.c@biocuresolutions.com>
Date: 2024-01-31
Subject: Phase II CTA Amendment Package for EMA Submission Status Update
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Team,

I'm calling this meeting together because we need to sync up on where we stand with the Phase II CTA Amendment Package for EMA Submission and make sure we're all aligned on next steps. We've got a lot of moving pieces across metabolite work streams, and a retrospective on our progress so far will help us identify what's working well and where we might need to adjust our approach.

The main thing I want us to cover is how our various task streams are progressing and what lessons we can extract from the first phase. We should talk through dependencies, any blockers we're seeing, and how we can tighten up our coordination moving forward. This is a good opportunity to reflect on what's gone smoothly and what we'd do differently.

Here's where things currently stand:

- Metabolite pharmacokinetic integration just got underway with Hadassa Coelho, roughly 15% complete
- Simona Leyva is looking into similar projects for metabolite bioanalytical validation
- Metabolite bioanalytical quantitation is still in early stages with Rosario, around 15-25% complete
- Freddy Black is making early headway on metabolite pathway integration, approximately 18% complete
- Kevim is roughly a quarter of the way through metabolite bioanalytical validation
- Ian is preparing the in vitro metabolite quantification resource library
- Afonso Nelson is mobilizing resources for metabolite bioanalytical integration launch
- Caterina created shared folders for in vitro metabolite identification materials
- Rik Curtis is assessing different metabolite bioanalytical quantitation frameworks
- Phase II CTA Amendment Package for EMA Submission is progressing well, around 40% done

I think this real-time visibility into where everyone's working will help us have a more focused conversation about the roadmap ahead and make sure we're set up for success on the remaining work for the EMA submission.

Regards,
William Bertho
Clinical Coordinator | Vendor Management Team
BioCure Solutions

P: +1 (415) 713-5722
E: Willbertho@biocuresolutions.com
[INSERT_BOX_LOGO]



<!-- END FETCHED CONTENT -->
