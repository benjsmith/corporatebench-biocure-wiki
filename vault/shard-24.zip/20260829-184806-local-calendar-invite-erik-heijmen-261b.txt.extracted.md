---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_erik_heijmen_261b.txt
ingested_at: 2026-08-29T18:48:06.096893+00:00
sha256: 14d3f390f8184b773b8855de14b0da36d5fc41b34423b28233c59473781ae5dc
bytes: 1969
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Facilities Team All-Hands

From: Erik Heijmen <erikh@biocuresolutions.com>
To: Leona Carretero <leonacarretero@biocuresolutions.com>, Rhys Stokes <rstokes@biocuresolutions.com>, Martim Novais <novais.martim@biocuresolutions.com>, Marie Nadal <Maen@biocuresolutions.com>, Fiene Kjellberg <fkjellberg@biocuresolutions.com>, Serafina Peters <serafina.peters@biocuresolutions.com>, Craig Clerc <craig.clerc@biocuresolutions.com>, Erik Heijmen <erikh@biocuresolutions.com>, Mateus Kent <mateus.k@biocuresolutions.com>, Anastasie Whitney <awhitney@biocuresolutions.com>, Ake Sordi <asordi@biocuresolutions.com>, Nanni Groen <nanni@biocuresolutions.com>, Matteo Nogueira <m.nogueira@biocuresolutions.com>, Shelley Schacht <shelley_schacht@biocuresolutions.com>, Ivonne Cammel <icammel@biocuresolutions.com>, Hugo Charrier <hcharrier@biocuresolutions.com>
Date: 2024-03-04

CALENDAR INVITE

You are invited to: Facilities Team All-Hands
Scheduled for: 2024-03-04

Organizer: Erik Heijmen (erikh@biocuresolutions.com)

Attendees:
  - Leona Carretero (leonacarretero@biocuresolutions.com)
  - Rhys Stokes (rstokes@biocuresolutions.com)
  - Martim Novais (novais.martim@biocuresolutions.com)
  - Marie Nadal (Maen@biocuresolutions.com)
  - Fiene Kjellberg (fkjellberg@biocuresolutions.com)
  - Serafina Peters (serafina.peters@biocuresolutions.com)
  - Craig Clerc (craig.clerc@biocuresolutions.com)
  - Erik Heijmen (erikh@biocuresolutions.com)
  - Mateus Kent (mateus.k@biocuresolutions.com)
  - Anastasie Whitney (awhitney@biocuresolutions.com)
  - Ake Sordi (asordi@biocuresolutions.com)
  - Nanni Groen (nanni@biocuresolutions.com)
  - Matteo Nogueira (m.nogueira@biocuresolutions.com)
  - Shelley Schacht (shelley_schacht@biocuresolutions.com)
  - Ivonne Cammel (icammel@biocuresolutions.com)
  - Hugo Charrier (hcharrier@biocuresolutions.com)

This meeting has been scheduled by Erik Heijmen.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
