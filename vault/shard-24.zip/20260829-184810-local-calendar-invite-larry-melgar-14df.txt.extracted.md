---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_larry_melgar_14df.txt
ingested_at: 2026-08-29T18:48:10.382444+00:00
sha256: ba0be51d7951cb87abd64ab8b49f729f00d8c4b731adaaf27f64fc7d8d33fa93
bytes: 647
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Jeffrey Juttner x Larry Melgar Meeting

From: Larry Melgar <Lawrence_melgar@biocuresolutions.com>
To: Jeffrey Juttner <juttner.Geoff@biocuresolutions.com>, Larry Melgar <Lawrence_melgar@biocuresolutions.com>
Date: 2024-03-15

CALENDAR INVITE

You are invited to: Jeffrey Juttner x Larry Melgar Meeting
Scheduled for: 2024-03-15

Organizer: Larry Melgar (Lawrence_melgar@biocuresolutions.com)

Attendees:
  - Jeffrey Juttner (juttner.Geoff@biocuresolutions.com)
  - Larry Melgar (Lawrence_melgar@biocuresolutions.com)

This meeting has been scheduled by Larry Melgar.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
