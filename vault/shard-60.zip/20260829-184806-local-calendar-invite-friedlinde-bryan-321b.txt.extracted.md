---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_friedlinde_bryan_321b.txt
ingested_at: 2026-08-29T18:48:06.841159+00:00
sha256: 5a7915a0b1d9d0515b908bfe582abeb96ff982f6311579421bbba27e4e251b7b
bytes: 647
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Reinaldo Kleibrink <> Friedlinde Bryan

From: Friedlinde Bryan <fbryan@biocuresolutions.com>
To: Friedlinde Bryan <fbryan@biocuresolutions.com>, Reinaldo Kleibrink <reinaldo.kleibrink@biocuresolutions.com>
Date: 2024-03-29

CALENDAR INVITE

You are invited to: Reinaldo Kleibrink <> Friedlinde Bryan
Scheduled for: 2024-03-29

Organizer: Friedlinde Bryan (fbryan@biocuresolutions.com)

Attendees:
  - Friedlinde Bryan (fbryan@biocuresolutions.com)
  - Reinaldo Kleibrink (reinaldo.kleibrink@biocuresolutions.com)

This meeting has been scheduled by Friedlinde Bryan.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
