---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_felicia_williams_6261.txt
ingested_at: 2026-08-29T18:48:06.269685+00:00
sha256: e7921d5ae4b0ff734e73690cb5c743c4be13c692c490f90242504983c41aba94
bytes: 1888
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Business Operations Team Standup

From: Felicia Williams <Fel.w@biocuresolutions.com>
To: Mirella Williams <m.williams@biocuresolutions.com>, Kenneth Korstman <Kendrick_korstman@biocuresolutions.com>, Nancy Thompson <Annt@biocuresolutions.com>, Hans Ortiz <hans.o@biocuresolutions.com>, Brian Carter <Bryantcarter@biocuresolutions.com>, Grace Wilson <grace@biocuresolutions.com>, Felicia Williams <Fel.w@biocuresolutions.com>, Brittany Ortiz <Bortiz@biocuresolutions.com>, Christine Ford <Cford@biocuresolutions.com>, Aurora Flores <auroraflores@biocuresolutions.com>, Sharon Morales <Shamorales@biocuresolutions.com>, Gelsomina Lee <glee@biocuresolutions.com>, Michelle Green <Mickey.green@biocuresolutions.com>, Justin Howard <Justus@biocuresolutions.com>, Edward Ketting <E.ketting@biocuresolutions.com>
Date: 2024-03-01

CALENDAR INVITE

You are invited to: Business Operations Team Standup
Scheduled for: 2024-03-01

Organizer: Felicia Williams (Fel.w@biocuresolutions.com)

Attendees:
  - Mirella Williams (m.williams@biocuresolutions.com)
  - Kenneth Korstman (Kendrick_korstman@biocuresolutions.com)
  - Nancy Thompson (Annt@biocuresolutions.com)
  - Hans Ortiz (hans.o@biocuresolutions.com)
  - Brian Carter (Bryantcarter@biocuresolutions.com)
  - Grace Wilson (grace@biocuresolutions.com)
  - Felicia Williams (Fel.w@biocuresolutions.com)
  - Brittany Ortiz (Bortiz@biocuresolutions.com)
  - Christine Ford (Cford@biocuresolutions.com)
  - Aurora Flores (auroraflores@biocuresolutions.com)
  - Sharon Morales (Shamorales@biocuresolutions.com)
  - Gelsomina Lee (glee@biocuresolutions.com)
  - Michelle Green (Mickey.green@biocuresolutions.com)
  - Justin Howard (Justus@biocuresolutions.com)
  - Edward Ketting (E.ketting@biocuresolutions.com)

This meeting has been scheduled by Felicia Williams.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
