---
source_path: /workspace/corporatebench/biocure/documents/re_email_Loyalty_point_utilization_0951.txt
ingested_at: 2026-08-29T18:53:29.523098+00:00
sha256: b7fb3a95eaac6b2221e1fb9c9ac03e650c6e07e57818ed94164b8c4acb3d655d
bytes: 1552
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: ceb3f247-1800-47fc-83bd-372d3e969c83
From: Michael Geiger <Micah.geiger@icloud.com>
To: Jessica Gunnarsson <Jessiegunnarsson@biocuresolutions.com>
Date: 2024-03-17
Subject: Re: Quick chat about maximizing travel rewards
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Received and noted. Very interesting. Let me know if you have any questions and I'll get back soon.

Michael

Michael Geiger
Account Manager | BioCure Solutions

Warm regards,
Michael


On 2024-03-16, Jessica Gunnarsson wrote:
> Hey Michael, I wanted to run something by you since we both travel for pharma conferences and site visits. I've been thinking about budget travel strategies lately, and I realized I'm sitting on a ton of loyalty points that I haven't really optimized. Have you figured out the best ways to use your points, or do you just let them pile up?
> 
> I'm trying to be more intentional about this stuff going forward. On a separate front, moving regulatory documentation assembly materials to long-term storage, so I'm trying to streamline some of my other commitments too. Anyway, if you've got any tips on loyalty point redemption or know which programs are actually worth the effort, I'd love to hear your thoughts. Seems like there's gotta be a smarter way to make these points work for us rather than just booking flights at face value.
> 
> Thanks,
> Jessica Gunnarsson
> Account Manager
> BioCure Solutions
> 
> Direct: +1 (415) 476-8448
> Jessiegunnarsson@biocuresolutions.com
> [INSERT_BOX_LOGO]



<!-- END FETCHED CONTENT -->
