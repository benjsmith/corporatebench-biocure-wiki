---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_scott_williams_75fb.txt
ingested_at: 2026-08-29T18:48:15.516467+00:00
sha256: c3dbdba955ba5fdb3254e1ef1e99cbf2db467c167fa1e15022f8202d6c949ed3
bytes: 639
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Metabolite structure validation Discussion

From: Scott Williams <williams.Squat@biocuresolutions.com>
To: Scott Williams <williams.Squat@biocuresolutions.com>, Jesus Ortiz <jesuso@biocuresolutions.com>
Date: 2024-01-22

CALENDAR INVITE

You are invited to: Metabolite structure validation Discussion
Scheduled for: 2024-01-22

Organizer: Scott Williams (williams.Squat@biocuresolutions.com)

Attendees:
  - Scott Williams (williams.Squat@biocuresolutions.com)
  - Jesus Ortiz (jesuso@biocuresolutions.com)

This meeting has been scheduled by Scott Williams.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
