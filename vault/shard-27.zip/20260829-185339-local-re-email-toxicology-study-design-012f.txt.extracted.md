---
source_path: /workspace/corporatebench/biocure/documents/re_email_Toxicology_Study_Design_012f.txt
ingested_at: 2026-08-29T18:53:39.980606+00:00
sha256: 633a80177eb285dd9a40a98bef132138dd429bef98bb009bb28fc4e94cf5f192
bytes: 1715
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: b52eba33-6c1d-47ad-80d7-91ea0afb2a48
From: Cecile Johnston <cecilej@biocuresolutions.com>
To: Jacques Jekel <jacquesjekel@yahoo.com>
Date: 2024-01-29
Subject: Re: Quick sync on preclinical work
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Received, thanks. Let's discuss this soon. I'll get back to you.

Cecile

Cecile Johnston
Content Writer, Facilities Team
BioCure Solutions

Direct: +1 (415) 683-6216
Email: cecilej@biocuresolutions.com
Slack: @cecilej
[INSERT_BOX_LOGO]

Regards,
Cecile


On 2024-01-28, Jacques Jekel wrote:
> Hi Cecile, wanted to touch base on a couple of things from the drug development side. We've been thinking through some of our business operations around how we're structuring the preclinical research timelines, and I realized we should probably align on what that looks like for our toxicology study design moving forward. The protocols are getting pretty detailed, and I want to make sure we're on the same page about the sequencing.
> 
> On a related note, I've been assigned to metabolite structural characterization starting today. This should give us a chance to dig deeper into the analytical work and really understand what we're seeing in the compound data. I'm pretty excited about it since characterization has always been the trickier part of these studies for me.
> 
> Let me know when you've got some time to sync up about the study design specifics. I think we can probably tackle a lot of this asynchronously at first, but it'd be good to walk through the methodology together at some point soon.
> 
> Regards,
> Jacques
> 
> Jacques Jekel
> Content Writer
> +1 (650) 128-6942 | jjekel@biocuresolutions.com



<!-- END FETCHED CONTENT -->
