---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_gesine_figueroa_568b.txt
ingested_at: 2026-08-29T18:48:07.326698+00:00
sha256: 04b4bf53d4ef6a260d164ccf7225ec48e68f3e49677b7b3b1a79ba888d4010da
bytes: 668
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Gesine Figueroa <> Jonathan Cordoba 1:1

From: Gesine Figueroa <figueroa.gesine@biocuresolutions.com>
To: Gesine Figueroa <figueroa.gesine@biocuresolutions.com>, Jonathan Cordoba <cordoba.Nathan@biocuresolutions.com>
Date: 2024-01-03

CALENDAR INVITE

You are invited to: Gesine Figueroa <> Jonathan Cordoba 1:1
Scheduled for: 2024-01-03

Organizer: Gesine Figueroa (figueroa.gesine@biocuresolutions.com)

Attendees:
  - Gesine Figueroa (figueroa.gesine@biocuresolutions.com)
  - Jonathan Cordoba (cordoba.Nathan@biocuresolutions.com)

This meeting has been scheduled by Gesine Figueroa.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
