---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_danique_bevilacqua_c502.txt
ingested_at: 2026-08-29T18:48:05.055238+00:00
sha256: 0a2e4b3088125fdf06b8c4b9b82e6c4e328313337492405b6bd91076dc14d794
bytes: 691
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Cecile Johnston & Danique Bevilacqua Check-in

From: Danique Bevilacqua <danique_bevilacqua@biocuresolutions.com>
To: Cecile Johnston <cecilej@biocuresolutions.com>, Danique Bevilacqua <danique_bevilacqua@biocuresolutions.com>
Date: 2024-01-15

CALENDAR INVITE

You are invited to: Cecile Johnston & Danique Bevilacqua Check-in
Scheduled for: 2024-01-15

Organizer: Danique Bevilacqua (danique_bevilacqua@biocuresolutions.com)

Attendees:
  - Cecile Johnston (cecilej@biocuresolutions.com)
  - Danique Bevilacqua (danique_bevilacqua@biocuresolutions.com)

This meeting has been scheduled by Danique Bevilacqua.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
