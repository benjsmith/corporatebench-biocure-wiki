---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sergius_lopes_f93f.txt
ingested_at: 2026-08-29T18:48:16.021113+00:00
sha256: 65d3832056c1b6d5489184454abe0a3ddb2112310e8ae731a7c10b03adc11711
bytes: 628
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Duncan Mayer x Sergius Lopes Meeting

From: Sergius Lopes <lopes.sergius@biocuresolutions.com>
To: Duncan Mayer <Dunk.mayer@biocuresolutions.com>, Sergius Lopes <lopes.sergius@biocuresolutions.com>
Date: 2024-01-12

CALENDAR INVITE

You are invited to: Duncan Mayer x Sergius Lopes Meeting
Scheduled for: 2024-01-12

Organizer: Sergius Lopes (lopes.sergius@biocuresolutions.com)

Attendees:
  - Duncan Mayer (Dunk.mayer@biocuresolutions.com)
  - Sergius Lopes (lopes.sergius@biocuresolutions.com)

This meeting has been scheduled by Sergius Lopes.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
