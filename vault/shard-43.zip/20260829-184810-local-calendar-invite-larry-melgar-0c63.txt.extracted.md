---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_larry_melgar_0c63.txt
ingested_at: 2026-08-29T18:48:10.372574+00:00
sha256: b945bfc1797dd66ba82edfa01896623a8f342c3450269dd2f6355b2b1e4b45a5
bytes: 2154
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Facilities Team Team Huddle

From: Larry Melgar <Lawrence_melgar@biocuresolutions.com>
To: Ronald Gonzales <Ronny.g@biocuresolutions.com>, Jeffrey Juttner <juttner.Geoff@biocuresolutions.com>, Patricia Bock <P.bock@biocuresolutions.com>, Matthew Roura <Matt_roura@biocuresolutions.com>, Christine Monteiro <Tmonteiro@biocuresolutions.com>, Paul Nunes <nunes.Polly@biocuresolutions.com>, Edward Soderholm <Esoderholm@biocuresolutions.com>, Mark Berre <mberre@biocuresolutions.com>, Stephanie Morais <Stephanimorais@biocuresolutions.com>, Helen Golden <Ellie.golden@biocuresolutions.com>, Jeffrey Woodward <Gwoodward@biocuresolutions.com>, William Rezende <Will_rezende@biocuresolutions.com>, Christopher Mota <C.mota@biocuresolutions.com>, Sarah Lejeune <S.lejeune@biocuresolutions.com>, Larry Melgar <Lawrence_melgar@biocuresolutions.com>, Christopher Cunha <Kit.c@biocuresolutions.com>, Nicholas Phillips <Nphillips@biocuresolutions.com>
Date: 2024-02-05

CALENDAR INVITE

You are invited to: Facilities Team Team Huddle
Scheduled for: 2024-02-05

Organizer: Larry Melgar (Lawrence_melgar@biocuresolutions.com)

Attendees:
  - Ronald Gonzales (Ronny.g@biocuresolutions.com)
  - Jeffrey Juttner (juttner.Geoff@biocuresolutions.com)
  - Patricia Bock (P.bock@biocuresolutions.com)
  - Matthew Roura (Matt_roura@biocuresolutions.com)
  - Christine Monteiro (Tmonteiro@biocuresolutions.com)
  - Paul Nunes (nunes.Polly@biocuresolutions.com)
  - Edward Soderholm (Esoderholm@biocuresolutions.com)
  - Mark Berre (mberre@biocuresolutions.com)
  - Stephanie Morais (Stephanimorais@biocuresolutions.com)
  - Helen Golden (Ellie.golden@biocuresolutions.com)
  - Jeffrey Woodward (Gwoodward@biocuresolutions.com)
  - William Rezende (Will_rezende@biocuresolutions.com)
  - Christopher Mota (C.mota@biocuresolutions.com)
  - Sarah Lejeune (S.lejeune@biocuresolutions.com)
  - Larry Melgar (Lawrence_melgar@biocuresolutions.com)
  - Christopher Cunha (Kit.c@biocuresolutions.com)
  - Nicholas Phillips (Nphillips@biocuresolutions.com)

This meeting has been scheduled by Larry Melgar.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
