---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_taylor_gillard_886c.txt
ingested_at: 2026-08-29T18:48:16.298819+00:00
sha256: 447248030bc4ac5a300a2714f0c6d022d7299701a6b47cddf22eb3c6a5f2eabd
bytes: 593
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Edouard Simon <> Taylor Gillard

From: Taylor Gillard <taylorg@biocuresolutions.com>
To: Taylor Gillard <taylorg@biocuresolutions.com>, Edouard Simon <esimon@biocuresolutions.com>
Date: 2024-02-21

CALENDAR INVITE

You are invited to: Edouard Simon <> Taylor Gillard
Scheduled for: 2024-02-21

Organizer: Taylor Gillard (taylorg@biocuresolutions.com)

Attendees:
  - Taylor Gillard (taylorg@biocuresolutions.com)
  - Edouard Simon (esimon@biocuresolutions.com)

This meeting has been scheduled by Taylor Gillard.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
