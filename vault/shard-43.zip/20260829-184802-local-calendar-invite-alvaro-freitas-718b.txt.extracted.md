---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_alvaro_freitas_718b.txt
ingested_at: 2026-08-29T18:48:02.120885+00:00
sha256: 3e556d646ae9908311188c8733f832e346f5ec642c8ababdbab1bd329bf76ab7
bytes: 2170
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team All-Hands

From: Alvaro Freitas <alvaro.freitas@biocuresolutions.com>
To: Guillaume Guidotti <guillaume@biocuresolutions.com>, Valerie Nibali <Val_nibali@biocuresolutions.com>, Tord Woods <t.woods@biocuresolutions.com>, Theodor Gaillard <theodor.g@biocuresolutions.com>, Maureen Sa <Marys@biocuresolutions.com>, Petra Haro <pharo@biocuresolutions.com>, Kathy Palmqvist <kpalmqvist@biocuresolutions.com>, Adelaide Keudel <Adie.k@biocuresolutions.com>, Fedde Holloway <f.holloway@biocuresolutions.com>, Frank Kinet <frank.kinet@biocuresolutions.com>, Virgilio Schwaiger <vschwaiger@biocuresolutions.com>, Etta Barbosa <ebarbosa@biocuresolutions.com>, Joaquina Baptista <joaquina.baptista@biocuresolutions.com>, Frederick Douglas <Erick_douglas@biocuresolutions.com>, Ingegerd Hultman <ingegerd_hultman@biocuresolutions.com>, Alvaro Freitas <alvaro.freitas@biocuresolutions.com>, Ellie Alarcon <Ealarcon@biocuresolutions.com>
Date: 2024-03-04

CALENDAR INVITE

You are invited to: Vendor Management Team All-Hands
Scheduled for: 2024-03-04

Organizer: Alvaro Freitas (alvaro.freitas@biocuresolutions.com)

Attendees:
  - Guillaume Guidotti (guillaume@biocuresolutions.com)
  - Valerie Nibali (Val_nibali@biocuresolutions.com)
  - Tord Woods (t.woods@biocuresolutions.com)
  - Theodor Gaillard (theodor.g@biocuresolutions.com)
  - Maureen Sa (Marys@biocuresolutions.com)
  - Petra Haro (pharo@biocuresolutions.com)
  - Kathy Palmqvist (kpalmqvist@biocuresolutions.com)
  - Adelaide Keudel (Adie.k@biocuresolutions.com)
  - Fedde Holloway (f.holloway@biocuresolutions.com)
  - Frank Kinet (frank.kinet@biocuresolutions.com)
  - Virgilio Schwaiger (vschwaiger@biocuresolutions.com)
  - Etta Barbosa (ebarbosa@biocuresolutions.com)
  - Joaquina Baptista (joaquina.baptista@biocuresolutions.com)
  - Frederick Douglas (Erick_douglas@biocuresolutions.com)
  - Ingegerd Hultman (ingegerd_hultman@biocuresolutions.com)
  - Alvaro Freitas (alvaro.freitas@biocuresolutions.com)
  - Ellie Alarcon (Ealarcon@biocuresolutions.com)

This meeting has been scheduled by Alvaro Freitas.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
