---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_marvin_mare_6aae.txt
ingested_at: 2026-08-29T18:48:12.030729+00:00
sha256: 5a032e1cc92ccc352952adb7b94b2c4b3bc6252a0e9ef2c613ea23a8a7886b18
bytes: 608
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Task: metabolite safety dossier compilation

From: Marvin Mare <Marv_mare@biocuresolutions.com>
To: Marvin Mare <Marv_mare@biocuresolutions.com>, Suus Desmet <sdesmet@biocuresolutions.com>
Date: 2024-02-07

CALENDAR INVITE

You are invited to: Task: metabolite safety dossier compilation
Scheduled for: 2024-02-07

Organizer: Marvin Mare (Marv_mare@biocuresolutions.com)

Attendees:
  - Marvin Mare (Marv_mare@biocuresolutions.com)
  - Suus Desmet (sdesmet@biocuresolutions.com)

This meeting has been scheduled by Marvin Mare.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
