---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sergius_lopes_aee3.txt
ingested_at: 2026-08-29T18:48:15.951705+00:00
sha256: 5d261362c572d42af1ec02628c0063e1997a509b57cd330335b50967804b099c
bytes: 2589
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Sync

From: Sergius Lopes <lopes.sergius@biocuresolutions.com>
To: Catalina Wikstrom <catalina.w@biocuresolutions.com>, Alison Sulzer <Ali_sulzer@biocuresolutions.com>, Sonia Davis <soniad@biocuresolutions.com>, Frederik Doorhof <f.doorhof@biocuresolutions.com>, Meghan Wood <wood.Meg@biocuresolutions.com>, Noemi O'Brien <no'brien@biocuresolutions.com>, Hansjurgen Stromberg <h.stromberg@biocuresolutions.com>, Carol Arvidsson <arvidsson.Carri@biocuresolutions.com>, Adrien Cambier <acambier@biocuresolutions.com>, Elisabeth Carlsson <carlsson.elisabeth@biocuresolutions.com>, Come Klingelhofer <comeklingelhofer@biocuresolutions.com>, Juliane Schrammel <juliane@biocuresolutions.com>, Allison Vizcaino <Allievizcaino@biocuresolutions.com>, Mila Nieuwenhuijsen <mila@biocuresolutions.com>, Marisol Underwood <munderwood@biocuresolutions.com>, Isabella Doherty <Nibd@biocuresolutions.com>, Liz Wester <liz_wester@biocuresolutions.com>, Anne Berendse <Ann.b@biocuresolutions.com>, Duncan Mayer <Dunk.mayer@biocuresolutions.com>, Micaela Martins <micaela@biocuresolutions.com>, Sergius Lopes <lopes.sergius@biocuresolutions.com>
Date: 2024-03-01

CALENDAR INVITE

You are invited to: Vendor Management Team Sync
Scheduled for: 2024-03-01

Organizer: Sergius Lopes (lopes.sergius@biocuresolutions.com)

Attendees:
  - Catalina Wikstrom (catalina.w@biocuresolutions.com)
  - Alison Sulzer (Ali_sulzer@biocuresolutions.com)
  - Sonia Davis (soniad@biocuresolutions.com)
  - Frederik Doorhof (f.doorhof@biocuresolutions.com)
  - Meghan Wood (wood.Meg@biocuresolutions.com)
  - Noemi O'Brien (no'brien@biocuresolutions.com)
  - Hansjurgen Stromberg (h.stromberg@biocuresolutions.com)
  - Carol Arvidsson (arvidsson.Carri@biocuresolutions.com)
  - Adrien Cambier (acambier@biocuresolutions.com)
  - Elisabeth Carlsson (carlsson.elisabeth@biocuresolutions.com)
  - Come Klingelhofer (comeklingelhofer@biocuresolutions.com)
  - Juliane Schrammel (juliane@biocuresolutions.com)
  - Allison Vizcaino (Allievizcaino@biocuresolutions.com)
  - Mila Nieuwenhuijsen (mila@biocuresolutions.com)
  - Marisol Underwood (munderwood@biocuresolutions.com)
  - Isabella Doherty (Nibd@biocuresolutions.com)
  - Liz Wester (liz_wester@biocuresolutions.com)
  - Anne Berendse (Ann.b@biocuresolutions.com)
  - Duncan Mayer (Dunk.mayer@biocuresolutions.com)
  - Micaela Martins (micaela@biocuresolutions.com)
  - Sergius Lopes (lopes.sergius@biocuresolutions.com)

This meeting has been scheduled by Sergius Lopes.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
