---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_keith_heinrich_972f.txt
ingested_at: 2026-08-29T18:48:09.750484+00:00
sha256: 5d04fe3022e1ad7a1f69c2acdf9e83135a6d85a8fc4beba80ec5b7dfd42ae84a
bytes: 3096
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Process Improvement Team All-Hands

From: Keith Heinrich <keith.h@biocuresolutions.com>
To: Gaspar Larsson <gasparl@biocuresolutions.com>, Edmond Lecomte <Ed.lecomte@biocuresolutions.com>, Inger Telesio <i.telesio@biocuresolutions.com>, Carin Duval <cduval@biocuresolutions.com>, Sante Carpaccio <scarpaccio@biocuresolutions.com>, Oskar Longoria <oskar@biocuresolutions.com>, Linnea Bruijne <linnea_bruijne@biocuresolutions.com>, Howard Collazo <Hcollazo@biocuresolutions.com>, Ewa Lemaire <elemaire@biocuresolutions.com>, Keith Heinrich <keith.h@biocuresolutions.com>, Audrey Tellez <Dtellez@biocuresolutions.com>, Jasmine Stout <stout.jasmine@biocuresolutions.com>, Melanie Ginese <Mellie.g@biocuresolutions.com>, Glen Ward <gward@biocuresolutions.com>, Lucas Swanson <Lswanson@biocuresolutions.com>, Milena Olivier <milena_olivier@biocuresolutions.com>, Giampiero Andrews <gandrews@biocuresolutions.com>, Kim Stey <kim.stey@biocuresolutions.com>, Simone Liegeois <simonel@biocuresolutions.com>, Paula Martinsson <Linamartinsson@biocuresolutions.com>, Rosalie Quinn <rosaliequinn@biocuresolutions.com>, Wendy Junk <Wjunk@biocuresolutions.com>, Jack Porto <jack_porto@biocuresolutions.com>, Teodosio Galvan <teodosio.g@biocuresolutions.com>, Leandro Wilhelm <leandrowilhelm@biocuresolutions.com>, Heidi Berggren <heidib@biocuresolutions.com>, Alexandria Paiva <Allapaiva@biocuresolutions.com>
Date: 2024-01-31

CALENDAR INVITE

You are invited to: Process Improvement Team All-Hands
Scheduled for: 2024-01-31

Organizer: Keith Heinrich (keith.h@biocuresolutions.com)

Attendees:
  - Gaspar Larsson (gasparl@biocuresolutions.com)
  - Edmond Lecomte (Ed.lecomte@biocuresolutions.com)
  - Inger Telesio (i.telesio@biocuresolutions.com)
  - Carin Duval (cduval@biocuresolutions.com)
  - Sante Carpaccio (scarpaccio@biocuresolutions.com)
  - Oskar Longoria (oskar@biocuresolutions.com)
  - Linnea Bruijne (linnea_bruijne@biocuresolutions.com)
  - Howard Collazo (Hcollazo@biocuresolutions.com)
  - Ewa Lemaire (elemaire@biocuresolutions.com)
  - Keith Heinrich (keith.h@biocuresolutions.com)
  - Audrey Tellez (Dtellez@biocuresolutions.com)
  - Jasmine Stout (stout.jasmine@biocuresolutions.com)
  - Melanie Ginese (Mellie.g@biocuresolutions.com)
  - Glen Ward (gward@biocuresolutions.com)
  - Lucas Swanson (Lswanson@biocuresolutions.com)
  - Milena Olivier (milena_olivier@biocuresolutions.com)
  - Giampiero Andrews (gandrews@biocuresolutions.com)
  - Kim Stey (kim.stey@biocuresolutions.com)
  - Simone Liegeois (simonel@biocuresolutions.com)
  - Paula Martinsson (Linamartinsson@biocuresolutions.com)
  - Rosalie Quinn (rosaliequinn@biocuresolutions.com)
  - Wendy Junk (Wjunk@biocuresolutions.com)
  - Jack Porto (jack_porto@biocuresolutions.com)
  - Teodosio Galvan (teodosio.g@biocuresolutions.com)
  - Leandro Wilhelm (leandrowilhelm@biocuresolutions.com)
  - Heidi Berggren (heidib@biocuresolutions.com)
  - Alexandria Paiva (Allapaiva@biocuresolutions.com)

This meeting has been scheduled by Keith Heinrich.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
