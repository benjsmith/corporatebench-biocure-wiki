---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_alec_huhn_8db3.txt
ingested_at: 2026-08-29T18:48:01.726406+00:00
sha256: c139d2fc3696d64fdcf382bbb75d6bde68d15a773cfbaf65349c43c1ff9c6e05
bytes: 608
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Joaquina Baptista + Alec Huhn Sync

From: Alec Huhn <alechuhn@biocuresolutions.com>
To: Joaquina Baptista <joaquina.baptista@biocuresolutions.com>, Alec Huhn <alechuhn@biocuresolutions.com>
Date: 2024-02-02

CALENDAR INVITE

You are invited to: Joaquina Baptista + Alec Huhn Sync
Scheduled for: 2024-02-02

Organizer: Alec Huhn (alechuhn@biocuresolutions.com)

Attendees:
  - Joaquina Baptista (joaquina.baptista@biocuresolutions.com)
  - Alec Huhn (alechuhn@biocuresolutions.com)

This meeting has been scheduled by Alec Huhn.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
