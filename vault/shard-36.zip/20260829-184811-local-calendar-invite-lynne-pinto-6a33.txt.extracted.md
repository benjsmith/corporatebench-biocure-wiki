---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_lynne_pinto_6a33.txt
ingested_at: 2026-08-29T18:48:11.125205+00:00
sha256: e9cd39cc12447669642a9df691d841b93734aa20aa59bc4d3b3e9b4082f464b5
bytes: 594
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Lynne Pinto <> Anais Rotter

From: Lynne Pinto <lynne_pinto@biocuresolutions.com>
To: Lynne Pinto <lynne_pinto@biocuresolutions.com>, Anais Rotter <anaisrotter@biocuresolutions.com>
Date: 2024-02-20

CALENDAR INVITE

You are invited to: Lynne Pinto <> Anais Rotter
Scheduled for: 2024-02-20

Organizer: Lynne Pinto (lynne_pinto@biocuresolutions.com)

Attendees:
  - Lynne Pinto (lynne_pinto@biocuresolutions.com)
  - Anais Rotter (anaisrotter@biocuresolutions.com)

This meeting has been scheduled by Lynne Pinto.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
