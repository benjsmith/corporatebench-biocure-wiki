---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_walter_campbell_95e7.txt
ingested_at: 2026-08-29T18:48:17.917468+00:00
sha256: f608b2f5bbbe19494240ed39bd02687ae05dc6cec92b261c5ba389d211f800c6
bytes: 2968
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Business Operations Team Standup

From: Walter Campbell <campbell.Wally@biocuresolutions.com>
To: Jurgen Silveira <j.silveira@biocuresolutions.com>, Emma Dossi <E.dossi@biocuresolutions.com>, Azahar Luciani <luciani.azahar@biocuresolutions.com>, Jeremiah Escamilla <Jereme.e@biocuresolutions.com>, Zacharie Schrant <schrant.zacharie@biocuresolutions.com>, Ronnie Becker <ronnie_becker@biocuresolutions.com>, Eduard Bird <bird.eduard@biocuresolutions.com>, Jennifer Winkler <J.winkler@biocuresolutions.com>, Frida Grassl <fgrassl@biocuresolutions.com>, Andrzej Reynolds <a.reynolds@biocuresolutions.com>, Sabrina Hall <Brina@biocuresolutions.com>, Walter Campbell <campbell.Wally@biocuresolutions.com>, Sam Jonsson <Sjonsson@biocuresolutions.com>, Nora Bonnin <Nonie.b@biocuresolutions.com>, David Lang <Davelang@biocuresolutions.com>, Sean Myers <sean_myers@biocuresolutions.com>, Antony Barros <a.barros@biocuresolutions.com>, Laurie Pina <lauriepina@biocuresolutions.com>, Ottone Jones <ottone@biocuresolutions.com>, Raoul Wolfe <r.wolfe@biocuresolutions.com>, Nina Dias <nina@biocuresolutions.com>, Emilia Caldera <ecaldera@biocuresolutions.com>, Noelia Mann <nmann@biocuresolutions.com>, Cameron Cabanas <Camc@biocuresolutions.com>, Suzanne Nerger <Snerger@biocuresolutions.com>, Gabriel Wittenboer <Gabe@biocuresolutions.com>
Date: 2024-02-02

CALENDAR INVITE

You are invited to: Business Operations Team Standup
Scheduled for: 2024-02-02

Organizer: Walter Campbell (campbell.Wally@biocuresolutions.com)

Attendees:
  - Jurgen Silveira (j.silveira@biocuresolutions.com)
  - Emma Dossi (E.dossi@biocuresolutions.com)
  - Azahar Luciani (luciani.azahar@biocuresolutions.com)
  - Jeremiah Escamilla (Jereme.e@biocuresolutions.com)
  - Zacharie Schrant (schrant.zacharie@biocuresolutions.com)
  - Ronnie Becker (ronnie_becker@biocuresolutions.com)
  - Eduard Bird (bird.eduard@biocuresolutions.com)
  - Jennifer Winkler (J.winkler@biocuresolutions.com)
  - Frida Grassl (fgrassl@biocuresolutions.com)
  - Andrzej Reynolds (a.reynolds@biocuresolutions.com)
  - Sabrina Hall (Brina@biocuresolutions.com)
  - Walter Campbell (campbell.Wally@biocuresolutions.com)
  - Sam Jonsson (Sjonsson@biocuresolutions.com)
  - Nora Bonnin (Nonie.b@biocuresolutions.com)
  - David Lang (Davelang@biocuresolutions.com)
  - Sean Myers (sean_myers@biocuresolutions.com)
  - Antony Barros (a.barros@biocuresolutions.com)
  - Laurie Pina (lauriepina@biocuresolutions.com)
  - Ottone Jones (ottone@biocuresolutions.com)
  - Raoul Wolfe (r.wolfe@biocuresolutions.com)
  - Nina Dias (nina@biocuresolutions.com)
  - Emilia Caldera (ecaldera@biocuresolutions.com)
  - Noelia Mann (nmann@biocuresolutions.com)
  - Cameron Cabanas (Camc@biocuresolutions.com)
  - Suzanne Nerger (Snerger@biocuresolutions.com)
  - Gabriel Wittenboer (Gabe@biocuresolutions.com)

This meeting has been scheduled by Walter Campbell.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
