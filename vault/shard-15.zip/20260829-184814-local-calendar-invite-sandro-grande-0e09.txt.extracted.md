---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sandro_grande_0e09.txt
ingested_at: 2026-08-29T18:48:14.859093+00:00
sha256: f52d02543621021b5962eab142b0fcfcf73224030ae000f607b40ad5d38abcde
bytes: 600
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Sandro Grande + Chad Thout Sync

From: Sandro Grande <sandrogrande@biocuresolutions.com>
To: Chad Thout <chadt@biocuresolutions.com>, Sandro Grande <sandrogrande@biocuresolutions.com>
Date: 2024-01-10

CALENDAR INVITE

You are invited to: Sandro Grande + Chad Thout Sync
Scheduled for: 2024-01-10

Organizer: Sandro Grande (sandrogrande@biocuresolutions.com)

Attendees:
  - Chad Thout (chadt@biocuresolutions.com)
  - Sandro Grande (sandrogrande@biocuresolutions.com)

This meeting has been scheduled by Sandro Grande.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
