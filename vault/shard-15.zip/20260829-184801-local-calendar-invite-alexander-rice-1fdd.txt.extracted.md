---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_alexander_rice_1fdd.txt
ingested_at: 2026-08-29T18:48:01.944124+00:00
sha256: c9bd088d3937d274822a1529573c69c8ab0511d74b438b98e715d44cdee3aa9e
bytes: 1912
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Facilities Team Sync

From: Alexander Rice <Al@biocuresolutions.com>
To: Laura Jennings <laura.jennings@biocuresolutions.com>, Ludivine Peterson <ludivine_peterson@biocuresolutions.com>, Laura Marchand <lauram@biocuresolutions.com>, Gary Lindstrom <garyl@biocuresolutions.com>, Alyssa Johnson <A.johnson@biocuresolutions.com>, Patricia Weissenbock <Pattyweissenbock@biocuresolutions.com>, Brian Carter <carter.Bryant@biocuresolutions.com>, George Miller <Georgie@biocuresolutions.com>, Sandra Walker <Sandywalker@biocuresolutions.com>, Ronja Moore <moore.ronja@biocuresolutions.com>, Mark Moulin <moulin.mark@biocuresolutions.com>, Larry Ahmed <Lahmed@biocuresolutions.com>, Alexander Rice <Al@biocuresolutions.com>, Robert Olsson <Hobkinolsson@biocuresolutions.com>, Manuel Roberts <roberts.Manny@biocuresolutions.com>
Date: 2024-01-31

CALENDAR INVITE

You are invited to: Facilities Team Sync
Scheduled for: 2024-01-31

Organizer: Alexander Rice (Al@biocuresolutions.com)

Attendees:
  - Laura Jennings (laura.jennings@biocuresolutions.com)
  - Ludivine Peterson (ludivine_peterson@biocuresolutions.com)
  - Laura Marchand (lauram@biocuresolutions.com)
  - Gary Lindstrom (garyl@biocuresolutions.com)
  - Alyssa Johnson (A.johnson@biocuresolutions.com)
  - Patricia Weissenbock (Pattyweissenbock@biocuresolutions.com)
  - Brian Carter (carter.Bryant@biocuresolutions.com)
  - George Miller (Georgie@biocuresolutions.com)
  - Sandra Walker (Sandywalker@biocuresolutions.com)
  - Ronja Moore (moore.ronja@biocuresolutions.com)
  - Mark Moulin (moulin.mark@biocuresolutions.com)
  - Larry Ahmed (Lahmed@biocuresolutions.com)
  - Alexander Rice (Al@biocuresolutions.com)
  - Robert Olsson (Hobkinolsson@biocuresolutions.com)
  - Manuel Roberts (roberts.Manny@biocuresolutions.com)

This meeting has been scheduled by Alexander Rice.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
