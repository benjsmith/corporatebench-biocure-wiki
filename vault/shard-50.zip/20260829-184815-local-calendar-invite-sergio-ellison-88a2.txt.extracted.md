---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sergio_ellison_88a2.txt
ingested_at: 2026-08-29T18:48:15.622980+00:00
sha256: 89aa4a2c3da2e597ea86d991c08deb279d8b922e2b2b851af8b5141876d1db93
bytes: 627
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Task: metabolite pharmacokinetic integration

From: Sergio Ellison <sergio.e@biocuresolutions.com>
To: Sergio Ellison <sergio.e@biocuresolutions.com>, Nadia Pearson <npearson@biocuresolutions.com>
Date: 2024-02-12

CALENDAR INVITE

You are invited to: Task: metabolite pharmacokinetic integration
Scheduled for: 2024-02-12

Organizer: Sergio Ellison (sergio.e@biocuresolutions.com)

Attendees:
  - Sergio Ellison (sergio.e@biocuresolutions.com)
  - Nadia Pearson (npearson@biocuresolutions.com)

This meeting has been scheduled by Sergio Ellison.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
