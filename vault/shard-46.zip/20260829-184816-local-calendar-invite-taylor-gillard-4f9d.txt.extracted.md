---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_taylor_gillard_4f9d.txt
ingested_at: 2026-08-29T18:48:16.259948+00:00
sha256: 59e87a73ba8f814293c1e89b8afcaac2a0505d9cf74d2654526f96f79334d5bf
bytes: 635
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Pharmacokinetic model verification - Work Session

From: Taylor Gillard <taylorg@biocuresolutions.com>
To: Taylor Gillard <taylorg@biocuresolutions.com>, Juliette Dongen <jdongen@biocuresolutions.com>
Date: 2024-03-07

CALENDAR INVITE

You are invited to: Pharmacokinetic model verification - Work Session
Scheduled for: 2024-03-07

Organizer: Taylor Gillard (taylorg@biocuresolutions.com)

Attendees:
  - Taylor Gillard (taylorg@biocuresolutions.com)
  - Juliette Dongen (jdongen@biocuresolutions.com)

This meeting has been scheduled by Taylor Gillard.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
