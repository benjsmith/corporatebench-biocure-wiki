---
source_path: /workspace/corporatebench/biocure/documents/meeting_minute_Organizational_Changes_and_Updates_4a74.txt
ingested_at: 2026-08-29T18:52:58.469001+00:00
sha256: eda056a30be0181ff69fec7038c3b1c03ab935f5e4d6353a4ed8c6fdf5637934
bytes: 6100
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 632c3c88-a539-49c4-82da-b6dfa6b278e3
From: Zoe Estes <zoe.estes@biocuresolutions.com>
To: Dawn Dohn <dawn.dohn@biocuresolutions.com>, Clemente Delmas <delmas.clemente@biocuresolutions.com>, Kyle Vasseur <k.vasseur@biocuresolutions.com>, Larissa Palomar <larissap@biocuresolutions.com>, Melina Montana <melina_montana@biocuresolutions.com>, Karin Amaldi <amaldi.karin@biocuresolutions.com>, Nelson Mari <Nmari@biocuresolutions.com>, Tijs Otero <tijs_otero@biocuresolutions.com>, Julio Barajas <juliobarajas@biocuresolutions.com>, Manuella Barrios <barrios.manuella@biocuresolutions.com>, Taylor Gillard <taylorg@biocuresolutions.com>, Juliette Dongen <jdongen@biocuresolutions.com>, Joshua Herzog <Joe@biocuresolutions.com>, Aaron Pottier <pottier.Erin@biocuresolutions.com>, Dorina Serra <dserra@biocuresolutions.com>, Adam Espana <aespana@biocuresolutions.com>, Marissa Bertin <Rissa.bertin@biocuresolutions.com>, Lisanne Sousa <lisanne.s@biocuresolutions.com>, Margareta Gierschner <mgierschner@biocuresolutions.com>, Vanesa Rodrigues <vrodrigues@biocuresolutions.com>, Coriolano King <coriolano.k@biocuresolutions.com>, Antoine Ibarra <aibarra@biocuresolutions.com>, Dimas Blom <dimas.b@biocuresolutions.com>, Gail Uhl <gailu@biocuresolutions.com>, Debra Requena <Debbier@biocuresolutions.com>, Melisa Lebron <melisa.lebron@biocuresolutions.com>, Bryan Schiaparelli <bryans@biocuresolutions.com>, Jeronimo Zobel <jeronimo.z@biocuresolutions.com>, Valentim Metz <valentim.metz@biocuresolutions.com>, Gustavo Magalhaes <gustavo_magalhaes@biocuresolutions.com>, Micha Geier <michag@biocuresolutions.com>, Jacqueline Pedrosa <Jack.pedrosa@biocuresolutions.com>, Annita Machado <annita.m@biocuresolutions.com>, Alexandra Booth <Sandy.b@biocuresolutions.com>, Carolina Kade <carolinak@biocuresolutions.com>, Curtis Washington <Curt_washington@biocuresolutions.com>, Chiara Geraci <chiara.geraci@biocuresolutions.com>, Tricia Bush <tricia.b@biocuresolutions.com>, Lara Grijalva <lara_grijalva@biocuresolutions.com>, Sole Olivares <sole@biocuresolutions.com>, Donald Ekman <Donny.ekman@biocuresolutions.com>, Daniele Radisch <dradisch@biocuresolutions.com>, Aime Hernandes <aimeh@biocuresolutions.com>, Misty Salz <msalz@biocuresolutions.com>, Evelio Morris <emorris@biocuresolutions.com>, Jinthe Sales <jinthe.sales@biocuresolutions.com>, Timoteo Dehon <tdehon@biocuresolutions.com>, Caren Rico <carenrico@biocuresolutions.com>, Ann Peeters <Npeeters@biocuresolutions.com>, Giuseppina Almqvist <galmqvist@biocuresolutions.com>, Evan Walcher <ewalcher@biocuresolutions.com>, Madeleine Martineau <madeleine_martineau@biocuresolutions.com>, Aylin Mende <aylin.m@biocuresolutions.com>, Cheryl Roberson <Cher_roberson@biocuresolutions.com>, Hilding Patterson <hilding.p@biocuresolutions.com>, Elif Pisani <elif.pisani@biocuresolutions.com>, Ashley Griffiths <A.griffiths@biocuresolutions.com>, Aurore Ribeiro <aurore_ribeiro@biocuresolutions.com>, Yeni Renard <yeni_renard@biocuresolutions.com>, Edouard Simon <esimon@biocuresolutions.com>, Lisa Marques <Lizmarques@biocuresolutions.com>, Samantha Carvalho <carvalho.Mantha@biocuresolutions.com>, Erhard Thorpe <thorpe.erhard@biocuresolutions.com>, Loic Barry <loicbarry@biocuresolutions.com>, Kimberly Roo <Kroo@biocuresolutions.com>, Margot Torrijos <torrijos.margot@biocuresolutions.com>, Ela Galvani <elagalvani@biocuresolutions.com>, Isabela Moureau <isabelam@biocuresolutions.com>, Tina Pfeiffer <Christina.p@biocuresolutions.com>, Emperatriz Anglada <eanglada@biocuresolutions.com>, Shaun Baldwin <Shawnbaldwin@biocuresolutions.com>, Dustin Torricelli <dtorricelli@biocuresolutions.com>, Julie Gustavsson <J.gustavsson@biocuresolutions.com>, Callum Lewis <clewis@biocuresolutions.com>, Wayne Schuster <wayneschuster@biocuresolutions.com>, Niels Scherms <nscherms@biocuresolutions.com>, Bo Cornejo <bocornejo@biocuresolutions.com>, Lisandro Hussein <lisandro@biocuresolutions.com>, Mamen Hanson <m.hanson@biocuresolutions.com>, Emile Erlacher <eerlacher@biocuresolutions.com>, Manu Lamb <manulamb@biocuresolutions.com>, Denise Lange <denisel@biocuresolutions.com>, Eleuterio Barrena <barrena.eleuterio@biocuresolutions.com>, Carly Vaz <carly_vaz@biocuresolutions.com>, Clarisa Mcdonald <cmcdonald@biocuresolutions.com>
Date: 2024-03-01
Subject: Information Technology & Infrastructure All-Hands
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi everyone,

Thanks for joining us at today's all-hands meeting. I wanted to get these minutes out while everything's fresh and make sure everyone has clarity on where we stand as a department. Here's what we covered:

1. The various FDA 21 CFR Part 11 Compliance Audit & Electronic Records System Remediation components are being assembled and tested as a complete package
2. Project F2CP1&HCARP is approaching three-quarters done, about 73% there

We spent a good portion of our time discussing the organizational changes ahead and how they'll affect our teams within the Information Technology & Infrastructure department. There was solid conversation around how our Facilities Team and Business Operations Team are positioned to support these transitions, and we talked through some of the immediate implications for our workflows and resource allocation. Everyone seemed aligned on the importance of maintaining momentum while we navigate these shifts.

Moving forward, we need all team leads to communicate these updates clearly to their respective teams and flag any concerns that come up. We'll be circling back on this next month to assess how things are progressing and to address any gaps. If you have questions in the meantime, don't hesitate to reach out directly.

Best,
Zoe

Zoe Estes
Director of IT Infrastructure & Information Security, Information Technology & Infrastructure
BioCure Solutions

United States, State of Delaware, Wilmington
+1 (510) 963-6128 | zoe.estes@biocuresolutions.com
www.linkedin.com/in/zoeestes44

Connect with our team: www.biocuresolutions.com/information_technology_infrastructure
[INSERT_HORIZONTAL_LOGO]



<!-- END FETCHED CONTENT -->
