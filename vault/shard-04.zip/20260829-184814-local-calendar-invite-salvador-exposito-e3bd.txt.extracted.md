---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_salvador_exposito_e3bd.txt
ingested_at: 2026-08-29T18:48:14.764504+00:00
sha256: 54c03e9a4d8804cf88f12563603ddf71a70a5c5ab32e9be0046ff85f046dc9b1
bytes: 708
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Working Session: comparative bioavailability qualification

From: Salvador Exposito <exposito.Sal@biocuresolutions.com>
To: Fedele Turchetta <fedele_turchetta@biocuresolutions.com>, Salvador Exposito <exposito.Sal@biocuresolutions.com>
Date: 2024-02-14

CALENDAR INVITE

You are invited to: Working Session: comparative bioavailability qualification
Scheduled for: 2024-02-14

Organizer: Salvador Exposito (exposito.Sal@biocuresolutions.com)

Attendees:
  - Fedele Turchetta (fedele_turchetta@biocuresolutions.com)
  - Salvador Exposito (exposito.Sal@biocuresolutions.com)

This meeting has been scheduled by Salvador Exposito.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
