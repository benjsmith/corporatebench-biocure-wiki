---
source_path: /workspace/corporatebench/biocure/documents/email_Biomarker_Discovery_Methods_4e83.txt
ingested_at: 2026-08-29T18:48:26.037574+00:00
sha256: d6174174b0d3946fc841bfab245d9d1370071aadc0efdf9c5228ce88915ffa56
bytes: 1560
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 25a81581-a1e5-44ba-8780-22a9aac22d4b
From: Theodor Gaillard <tgaillard@gmail.com>
To: Frank Kinet <frankkinet@gmail.com>
Date: 2024-01-02
Subject: Checking in on biomarker discovery approaches
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Frank, I wanted to touch base about some of the work we're doing around biomarker identification within our drug development operations. Recently, building rapport with solubility testing protocol stakeholder community, and I've been thinking about how this connects to our broader business operations strategy and the methods we're using for biomarker discovery.

From a practical standpoint, I've been looking into some of the different biomarker discovery methods that could improve our solubility testing protocol. There are a few interesting approaches out there - some labs are getting solid results with mass spectrometry-based techniques, while others are leaning more into computational modeling. I think understanding these different methodologies could really help us streamline our current process and make our testing more efficient.

I'd like to grab some time with you soon to walk through what we're seeing and get your perspective. Your experience with the solubility side of things would be super valuable as we think about which discovery methods might work best for our workflow. Let me know what your schedule looks like next week.

Thank you,
Theodor Gaillard

Theodor Gaillard
Chemist
+1 (415) 215-2363 | theodor.g@biocuresolutions.com



<!-- END FETCHED CONTENT -->
