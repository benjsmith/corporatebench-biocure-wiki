---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_fernanda_pla_203d.txt
ingested_at: 2026-08-29T18:48:06.450015+00:00
sha256: d981b5ed17ad265b9fd4080a72c8393b77956ee0fe84e74315e02154e883be96
bytes: 3290
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Team Meeting

From: Fernanda Pla <fernandap@biocuresolutions.com>
To: Sophia Guerreiro <Sophie@biocuresolutions.com>, Goran Estevez <goran.e@biocuresolutions.com>, Swantje Burke <sburke@biocuresolutions.com>, Brayan Alves <balves@biocuresolutions.com>, Julia Dewez <Jilldewez@biocuresolutions.com>, Jordan Rackham <jordan.r@biocuresolutions.com>, Jimmy Mendes <jmendes@biocuresolutions.com>, Peter Pratt <Ppratt@biocuresolutions.com>, Flor Teixeira <teixeira.flor@biocuresolutions.com>, Fernanda Pla <fernandap@biocuresolutions.com>, Emanuel Andre <Manuelandre@biocuresolutions.com>, Kayla Jenkins <K.jenkins@biocuresolutions.com>, Adele Sandin <Asandin@biocuresolutions.com>, Deborah Thornton <Debt@biocuresolutions.com>, Stacey Montoya <montoya.Stacie@biocuresolutions.com>, Hollie Hammerl <hollieh@biocuresolutions.com>, Mike Walsh <Micky.walsh@biocuresolutions.com>, Cristina Cruz <cruz.cristina@biocuresolutions.com>, Alphons Diallo <adiallo@biocuresolutions.com>, Dorothy Goodwin <Dgoodwin@biocuresolutions.com>, Ines Rose <ines.r@biocuresolutions.com>, Annett Cervantes <a.cervantes@biocuresolutions.com>, Jeremy Dehmel <dehmel.Jezza@biocuresolutions.com>, Adrienne Porter <porter.Enne@biocuresolutions.com>, Stephen Stephens <Sstephens@biocuresolutions.com>, Carlos Vicens <carlos@biocuresolutions.com>, Andres Brunelleschi <abrunelleschi@biocuresolutions.com>, Natalie Bultot <Nettie@biocuresolutions.com>, Antonin Lourenco <antonin.l@biocuresolutions.com>
Date: 2024-01-05

CALENDAR INVITE

You are invited to: Vendor Management Team Team Meeting
Scheduled for: 2024-01-05

Organizer: Fernanda Pla (fernandap@biocuresolutions.com)

Attendees:
  - Sophia Guerreiro (Sophie@biocuresolutions.com)
  - Goran Estevez (goran.e@biocuresolutions.com)
  - Swantje Burke (sburke@biocuresolutions.com)
  - Brayan Alves (balves@biocuresolutions.com)
  - Julia Dewez (Jilldewez@biocuresolutions.com)
  - Jordan Rackham (jordan.r@biocuresolutions.com)
  - Jimmy Mendes (jmendes@biocuresolutions.com)
  - Peter Pratt (Ppratt@biocuresolutions.com)
  - Flor Teixeira (teixeira.flor@biocuresolutions.com)
  - Fernanda Pla (fernandap@biocuresolutions.com)
  - Emanuel Andre (Manuelandre@biocuresolutions.com)
  - Kayla Jenkins (K.jenkins@biocuresolutions.com)
  - Adele Sandin (Asandin@biocuresolutions.com)
  - Deborah Thornton (Debt@biocuresolutions.com)
  - Stacey Montoya (montoya.Stacie@biocuresolutions.com)
  - Hollie Hammerl (hollieh@biocuresolutions.com)
  - Mike Walsh (Micky.walsh@biocuresolutions.com)
  - Cristina Cruz (cruz.cristina@biocuresolutions.com)
  - Alphons Diallo (adiallo@biocuresolutions.com)
  - Dorothy Goodwin (Dgoodwin@biocuresolutions.com)
  - Ines Rose (ines.r@biocuresolutions.com)
  - Annett Cervantes (a.cervantes@biocuresolutions.com)
  - Jeremy Dehmel (dehmel.Jezza@biocuresolutions.com)
  - Adrienne Porter (porter.Enne@biocuresolutions.com)
  - Stephen Stephens (Sstephens@biocuresolutions.com)
  - Carlos Vicens (carlos@biocuresolutions.com)
  - Andres Brunelleschi (abrunelleschi@biocuresolutions.com)
  - Natalie Bultot (Nettie@biocuresolutions.com)
  - Antonin Lourenco (antonin.l@biocuresolutions.com)

This meeting has been scheduled by Fernanda Pla.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
