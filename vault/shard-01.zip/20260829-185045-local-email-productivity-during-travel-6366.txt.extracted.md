---
source_path: /workspace/corporatebench/biocure/documents/email_Productivity_during_travel_6366.txt
ingested_at: 2026-08-29T18:50:45.959254+00:00
sha256: 1399e4f0a33792e5ec8dd9d877dd53ab7667041c6342d58a37454c7a107032b7
bytes: 1553
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 942d6ca2-505e-4ba3-9738-3a02df932801
From: Tord Woods <tordwoods@gmail.com>
To: Andre Winters <Drea@yahoo.com>
Date: 2024-01-15
Subject: Managing work during commute time
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Drea, I wanted to touch base about something we discussed briefly last week regarding productivity during our commutes and travel. I've been thinking about how to make better use of those transit hours, especially when we're heading to client meetings or conferences. It's casual watercooler-type conversation, but I find it relevant to how we structure our work days.

I've noticed that having a solid plan before traveling makes a real difference in what I can actually accomplish. On the transportation front, I've started prepping tasks that don't require full connectivity—things like reviewing documents or organizing data. In the same vein, I'm completing bioavailability data integration by month end, so I'm trying to batch my commute work strategically around that timeline. The key seems to be identifying which tasks travel well and which ones really need me at my desk.

I'm curious if you've found any particular methods that work for you when traveling or commuting. I'd rather not waste those hours, but I also want to be realistic about what's achievable in transit versus office time. Let me know if you've discovered any good strategies—I'm always looking to optimize how I spend that time.

Kind regards,
Tord

Tord Woods
Chemist | +1 (415) 551-1822



<!-- END FETCHED CONTENT -->
