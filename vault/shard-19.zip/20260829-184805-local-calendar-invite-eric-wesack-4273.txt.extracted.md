---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_eric_wesack_4273.txt
ingested_at: 2026-08-29T18:48:05.879322+00:00
sha256: 456572ba02ec1a7792448c8c969d048b80e306167470e15562004151c13f96cf
bytes: 600
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Teodoro Wilson <> Eric Wesack 1:1

From: Eric Wesack <Rwesack@biocuresolutions.com>
To: Eric Wesack <Rwesack@biocuresolutions.com>, Teodoro Wilson <teodoro_wilson@biocuresolutions.com>
Date: 2024-02-28

CALENDAR INVITE

You are invited to: Teodoro Wilson <> Eric Wesack 1:1
Scheduled for: 2024-02-28

Organizer: Eric Wesack (Rwesack@biocuresolutions.com)

Attendees:
  - Eric Wesack (Rwesack@biocuresolutions.com)
  - Teodoro Wilson (teodoro_wilson@biocuresolutions.com)

This meeting has been scheduled by Eric Wesack.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
