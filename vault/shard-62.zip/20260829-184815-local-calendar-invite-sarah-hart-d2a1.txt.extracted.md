---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_sarah_hart_d2a1.txt
ingested_at: 2026-08-29T18:48:15.458541+00:00
sha256: 5926a9bfb9ce09c598bf7117906a87fba759ba2d7579c574a9ab37823dc48da8
bytes: 553
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Gary Saura <> Sarah Hart 1:1

From: Sarah Hart <Sarah@biocuresolutions.com>
To: Gary Saura <gsaura@biocuresolutions.com>, Sarah Hart <Sarah@biocuresolutions.com>
Date: 2024-01-05

CALENDAR INVITE

You are invited to: Gary Saura <> Sarah Hart 1:1
Scheduled for: 2024-01-05

Organizer: Sarah Hart (Sarah@biocuresolutions.com)

Attendees:
  - Gary Saura (gsaura@biocuresolutions.com)
  - Sarah Hart (Sarah@biocuresolutions.com)

This meeting has been scheduled by Sarah Hart.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
