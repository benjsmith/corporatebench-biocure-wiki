---
source_path: /workspace/corporatebench/biocure/documents/meeting_minute_Project_Retrospective_and_Lessons_Learne_ebc5.txt
ingested_at: 2026-08-29T18:52:59.716058+00:00
sha256: fdbf49d70bc18d7860f80960cd017ffeb691db56eb0cbdee30d7e1f5b01dff01
bytes: 2337
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: b42aa6b9-71af-43c9-802a-3669d80378da
From: Manon Warmer <warmer.manon@biocuresolutions.com>
To: Jason Moreira <jason@biocuresolutions.com>, Fernando Torres <fernando.t@biocuresolutions.com>, Emilio Leblanc <emilio@biocuresolutions.com>, Tiffany Giulietti <Tiffy.giulietti@biocuresolutions.com>, Elisabet Kelley <e.kelley@biocuresolutions.com>, Michaela Sanders <michaela@biocuresolutions.com>, Hector Collet <collet.hector@biocuresolutions.com>, Bjorn Fleury <b.fleury@biocuresolutions.com>, Henri Wells <henriw@biocuresolutions.com>
Date: 2024-03-08
Subject: ASC 606 Milestone Revenue Reconciliation Tool Status Update
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Jason Moreira, Fernando, Emilio Leblanc, Tiffany Giulietti, Elisabet Kelley, Michaela, Hector, Bjorn, and Henri Wells,

Thank you all for joining our project meeting today. I wanted to document the key discussions and decisions we covered regarding the ASC 606 Milestone Revenue Reconciliation Tool project, and ensure everyone has clarity on our current status and next steps.

We reviewed the overall project progress and discussed several important workstreams that are moving forward. Here's what we covered:

- Henri and Jason Moreira are almost finished with bioanalytical method validation, around 80-90% there
- ASC 606 Milestone Revenue Reconciliation Tool is undergoing field trials with users who represent our target audience

We also discussed the field trial process and confirmed that user feedback is critical to refining the tool before broader rollout. The team agreed that we should continue monitoring user interactions closely to identify any issues or enhancements. Moving forward, Henri and Jason Moreira will continue their work on the bioanalytical method validation component and provide a detailed update at our next meeting. Tiffany and Elisabet will coordinate on documenting lessons learned from the field trials and compile recommendations for adjustments. Please ensure all action items are tracked in our project management system, and let me know if you have any questions about assignments or timeline expectations.

Best regards,
Manon

Manon Warmer
Accountant
Facilities Team | Finance & Accounting
BioCure Solutions

+1 (650) 570-2210 | warmer.manon@biocuresolutions.com



<!-- END FETCHED CONTENT -->
