---
source_path: /workspace/corporatebench/biocure/documents/email_Toll_road_expenses_ead7.txt
ingested_at: 2026-08-29T18:52:29.546325+00:00
sha256: 8ea70c27e2e31809737d6e4fa81168c2ecbd0bd47c4929ce5815cde37d13c133
bytes: 1189
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 2d45297a-ba53-4616-a7b8-9ce83f7cf0b7
From: Cristal Jackson <jackson.cristal@hotmail.com>
To: Ximena Lindfors <ximena.lindfors@biocuresolutions.com>
Date: 2024-03-20
Subject: Quick question about commute reimbursement
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Ximena, I wanted to touch base about something I've been meaning to ask. I've noticed our transportation costs keep adding up, especially with all the driving I've been doing for work lately. Between gas and the toll road expenses on my commute, it's gotten to be a bit much, and I'm wondering if there's a process for getting reimbursed or if I should be tracking these differently.

Meanwhile, I'm embarking on pharmacokinetic parameter compilation starting today, so my schedule is getting pretty packed with the workload. I'm hoping to get clarity on the transportation reimbursement policy when you have a moment—specifically how toll road charges should be documented and submitted. Let me know if you've dealt with this before or if there's someone else I should reach out to about it.

Best,
Cristal Jackson

Cristal Jackson
Chemist
M: +1 (415) 492-2994



<!-- END FETCHED CONTENT -->
