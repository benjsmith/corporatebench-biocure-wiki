---
source_path: /workspace/corporatebench/biocure/documents/email_Group_discount_opportunities_e7fe.txt
ingested_at: 2026-08-29T18:49:31.318208+00:00
sha256: f0fd529c26f4f9877d59227d2b46a24de4f95becbbd9ba5ab6e18d05eb81321d
bytes: 1289
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 7f4be39e-810e-4e39-bfc1-a3f87908a319
From: Jessica Bjorklund <Jess.bjorklund@yahoo.com>
To: Guilherme Bjork <guilherme_bjork@biocuresolutions.com>
Date: 2024-01-27
Subject: Quick thought on that conference trip we chatted about
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Guilherme, I wanted to touch base on a couple things - first, I'm finishing the last of bioavailability assessment documentation tasks, which has me swamped this week. But on a lighter note,

I've been doing some research on group discount opportunities for the conference trip we mentioned in passing the other day. You know how travel can get pricey, and I thought it'd be worth exploring budget-friendly options we might've overlooked.

So turns out there's a pretty sweet group rate available if we can coordinate with at least 8-10 people from the company. We're talking meaningful savings on both the hotel and flights when you bundle them together. It's one of those situations where individual deals are meh, but when you pool everyone together, the numbers actually make sense. Anyway, thought I'd flag this before everyone books independently. Want me to dig up the specifics?

Thanks,
Jessica Bjorklund
Trial Coordinator
M: +1 (408) 394-2778



<!-- END FETCHED CONTENT -->
