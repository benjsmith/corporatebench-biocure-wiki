---
source_path: /workspace/corporatebench/biocure/documents/email_Electronic_Submission_Format_f0b2.txt
ingested_at: 2026-08-29T18:49:10.894696+00:00
sha256: c106d34ae6da123418853ee8884712112951a255b2ab4947a9e6668756d5d659
bytes: 1563
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 20011033-47b9-4265-bd2b-a2c9dfa1aef6
From: Patty Heredia <Patricia_heredia@biocuresolutions.com>
To: Bernt Loreal <loreal.bernt@gmail.com>
Date: 2024-01-07
Subject: Quick update on the submission prep work
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hey Bernt, I wanted to touch base about where we're at with the regulatory submission preparation stuff. We've been making good progress on getting all our documentation aligned with the electronic submission format requirements, and I think we're in a pretty solid place heading into next week. There are still a few formatting tweaks we need to nail down to make sure everything passes the validation checks.

On top of that, I've been juggling a couple of things across our business operations side of things. Meanwhile, my bioavailability data integration assignment concludes next week, so I'm going to be a bit more heads-down for the next few days getting that wrapped up. I wanted to give you a heads up in case you need anything urgent from me during that time.

Once I'm done with that assignment,

I'd love to reconnect and make sure we've got the electronic submission format locked in completely. I think we're close to having all the pieces in place, and it'd be great to do a final check together before we hand things off to the submission team. Let me know if you see any gaps we should address!

Regards,
Patty Heredia
Analyst
BioCure Solutions

Patricia_heredia@biocuresolutions.com
Desk: +1 (510) 698-3397
Mobile: +1 (510) 939-6815



<!-- END FETCHED CONTENT -->
