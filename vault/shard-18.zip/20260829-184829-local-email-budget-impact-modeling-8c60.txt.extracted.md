---
source_path: /workspace/corporatebench/biocure/documents/email_Budget_Impact_Modeling_8c60.txt
ingested_at: 2026-08-29T18:48:29.232000+00:00
sha256: 788794e4cdc88f6389ef7abfc2c13496e94335ab6940793f3713cd80781a8d58
bytes: 1483
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: 54c9d4cc-6e65-4099-bcdc-d72d64fbb2dc
From: Julia Dewez <Jill.dewez@gmail.com>
To: Deborah Thornton <Dthornton@gmail.com>
Date: 2024-01-11
Subject: Quick sync on drug pricing and our modeling approach
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hi Deborah, wanted to touch base on a couple of things I'm working through on the business operations side. We've been looking at how our drug sales pricing negotiations are shaping up, and I've realized we need to get more rigorous about our budget impact modeling going forward. The numbers have been coming in pretty scattered, and I think having a more structured approach would really help us make better decisions.

Related to this, I'm completing solubility data integration by month end, so I'll have better visibility into some of the data dependencies we're dealing with. I know that's been a pain point on your end too. Once I get through that,

I think we'll be in a much better position to run some meaningful scenarios for the pricing team and show them how different negotiation outcomes might affect our bottom line.

Could we grab 15 minutes next week to walk through what you're seeing from your end? I'd like to align on what metrics matter most for these models before we hand anything off to the commercial folks. Thanks for your patience on this—I know it's been a bit of a moving target.

Kind regards,
Jill

Julia Dewez
Accountant
M: +1 (408) 725-5437



<!-- END FETCHED CONTENT -->
