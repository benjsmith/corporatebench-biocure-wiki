---
source_path: /workspace/corporatebench/biocure/documents/agenda_Quality_Assurance_and_Testing_Review_26dd.txt
ingested_at: 2026-08-29T18:47:58.071804+00:00
sha256: 018eb7a1a85aae5125faeb26d976d2ead63360e808c41503476f776dba0ce65d
bytes: 3156
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Message-ID: ddc6e7c5-0a55-4ca2-89e7-7e7ed049da99
From: Anna Munson <Nan@biocuresolutions.com>
To: Gary Ortiz <garyortiz@biocuresolutions.com>, Samuel Bertrand <Sam.bertrand@biocuresolutions.com>, Sharon Morales <Smorales@biocuresolutions.com>, Ernesto Wilson <ernesto.w@biocuresolutions.com>, Jessica Hill <J.hill@biocuresolutions.com>, Robert Rijks <rijks.Bobby@biocuresolutions.com>, Sylvester Martin <martin.Sly@biocuresolutions.com>, Anthony Brown <Antbrown@biocuresolutions.com>, Milica Murphy <milica.m@biocuresolutions.com>, Robin Martin <rmartin@biocuresolutions.com>, Mark Farias <mark.f@biocuresolutions.com>, Bethany Williams <bethany.williams@biocuresolutions.com>, Andrew Quesada <Randy_quesada@biocuresolutions.com>
Date: 2024-01-08
Subject: GMP Facility Inspection Audit Checklist System Project Meeting
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 7bit

Hey Gary, Sam, Sharon Morales, Ernesto, Jess, Robert Rijks, Sly, Ant, Milica, Robin Martin, Mark Farias,

Bethany Williams, and Andrew,

I wanted to get everyone together for our GMP Facility Inspection Audit Checklist System project meeting to review where we're at with quality assurance and testing. We're still in the startup phase and there's a lot of ground to cover as we build out this system, so I think it'd be helpful to sync up on progress and make sure we're all aligned on next steps.

Here's what's been happening across the team:

- Shay has the final stretch of preliminary compound screening underway, around 84% finished
- Anthony Brown has solubility parameter analysis in its final stages, roughly 87% done
- Ernesto is putting finishing touches on clinical protocol documentation, about 95% complete
- Sam is roughly a third done with dissolution rate coefficient analysis
- Robert Rijks is about 55-60% through solubility data documentation
- Robin Martin just set up tracking systems for metabolic stability assessment
- Gary has the core compound potency data analysis components working
- Jessica Hill has the bulk of compound stability data compilation done, roughly 70%
- Sylvester delivered the first set of solubility data integration documents
- Milica is roughly a quarter of the way through bioavailability coefficient refinement
- Shay circulated the metabolic clearance rate compilation announcement to all departments
- GMP Facility Inspection Audit Checklist System is in the startup phase, about 12% done so far

I'd really like us to focus our discussion on how we're handling quality assurance across these different workstreams and where we might have any testing bottlenecks. We should talk through our testing strategy for the various data compilations and analyses we've got underway, and make sure we've got solid processes in place as things ramp up. It'd also be good to identify any dependencies between tasks that might impact our timeline and coordinate how we're approaching documentation and validation across the project.

Thanks,
Anna Munson

Anna Munson
Compliance Specialist
Facilities Team, Regulatory Affairs & Compliance
BioCure Solutions

+1 (415) 842-7792 | Nan@biocuresolutions.com



<!-- END FETCHED CONTENT -->
