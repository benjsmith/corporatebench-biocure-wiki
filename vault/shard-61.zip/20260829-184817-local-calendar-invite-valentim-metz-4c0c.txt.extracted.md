---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_valentim_metz_4c0c.txt
ingested_at: 2026-08-29T18:48:17.472467+00:00
sha256: b25784a7e848935e6bd660d353d3f6709db330a87eea3021a7a1058c28441e0c
bytes: 2095
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Facilities Team Team Meeting

From: Valentim Metz <valentim.metz@biocuresolutions.com>
To: Dawn Dohn <dawn.dohn@biocuresolutions.com>, Antoine Ibarra <aibarra@biocuresolutions.com>, Melisa Lebron <melisa.lebron@biocuresolutions.com>, Bryan Schiaparelli <bryans@biocuresolutions.com>, Valentim Metz <valentim.metz@biocuresolutions.com>, Tricia Bush <tricia.b@biocuresolutions.com>, Sole Olivares <sole@biocuresolutions.com>, Donald Ekman <Donny.ekman@biocuresolutions.com>, Misty Salz <msalz@biocuresolutions.com>, Caren Rico <carenrico@biocuresolutions.com>, Erhard Thorpe <thorpe.erhard@biocuresolutions.com>, Margot Torrijos <torrijos.margot@biocuresolutions.com>, Isabela Moureau <isabelam@biocuresolutions.com>, Julie Gustavsson <J.gustavsson@biocuresolutions.com>, Mamen Hanson <m.hanson@biocuresolutions.com>, Manu Lamb <manulamb@biocuresolutions.com>, Clarisa Mcdonald <cmcdonald@biocuresolutions.com>
Date: 2024-01-04

CALENDAR INVITE

You are invited to: Facilities Team Team Meeting
Scheduled for: 2024-01-04

Organizer: Valentim Metz (valentim.metz@biocuresolutions.com)

Attendees:
  - Dawn Dohn (dawn.dohn@biocuresolutions.com)
  - Antoine Ibarra (aibarra@biocuresolutions.com)
  - Melisa Lebron (melisa.lebron@biocuresolutions.com)
  - Bryan Schiaparelli (bryans@biocuresolutions.com)
  - Valentim Metz (valentim.metz@biocuresolutions.com)
  - Tricia Bush (tricia.b@biocuresolutions.com)
  - Sole Olivares (sole@biocuresolutions.com)
  - Donald Ekman (Donny.ekman@biocuresolutions.com)
  - Misty Salz (msalz@biocuresolutions.com)
  - Caren Rico (carenrico@biocuresolutions.com)
  - Erhard Thorpe (thorpe.erhard@biocuresolutions.com)
  - Margot Torrijos (torrijos.margot@biocuresolutions.com)
  - Isabela Moureau (isabelam@biocuresolutions.com)
  - Julie Gustavsson (J.gustavsson@biocuresolutions.com)
  - Mamen Hanson (m.hanson@biocuresolutions.com)
  - Manu Lamb (manulamb@biocuresolutions.com)
  - Clarisa Mcdonald (cmcdonald@biocuresolutions.com)

This meeting has been scheduled by Valentim Metz.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
