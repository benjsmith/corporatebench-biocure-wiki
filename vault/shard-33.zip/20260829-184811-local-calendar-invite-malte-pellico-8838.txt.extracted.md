---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_malte_pellico_8838.txt
ingested_at: 2026-08-29T18:48:11.314192+00:00
sha256: 23c2860d302842f33423c6330c5e5f691ebd0e095fb51fe0b728fac70239c7d0
bytes: 616
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Claudia Johnson & Malte Pellico Check-in

From: Malte Pellico <mpellico@biocuresolutions.com>
To: Malte Pellico <mpellico@biocuresolutions.com>, Claudia Johnson <Claud.j@biocuresolutions.com>
Date: 2024-03-13

CALENDAR INVITE

You are invited to: Claudia Johnson & Malte Pellico Check-in
Scheduled for: 2024-03-13

Organizer: Malte Pellico (mpellico@biocuresolutions.com)

Attendees:
  - Malte Pellico (mpellico@biocuresolutions.com)
  - Claudia Johnson (Claud.j@biocuresolutions.com)

This meeting has been scheduled by Malte Pellico.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
