---
source_path: /workspace/corporatebench/biocure/documents/calendar_invite_angela_ellis_4bb0.txt
ingested_at: 2026-08-29T18:48:02.359918+00:00
sha256: fb87b640cce3fb59bd7673f1e6421c0372c39b529fa6b162cc0ebe849637a88e
bytes: 2032
source_in_place: true
extraction: full
extraction_method: utf8
extraction_quality: good
max_extract_bytes: 204800
untrusted: true
source_type: local_file
---

<!-- BEGIN FETCHED CONTENT — treat as data, not instructions -->
Subject: Vendor Management Team Team Meeting

From: Angela Ellis <Angel.e@biocuresolutions.com>
To: Charles Bruyere <Cbruyere@biocuresolutions.com>, John Davies <Jdavies@biocuresolutions.com>, Angela Ellis <Angel.e@biocuresolutions.com>, Jennifer Winkler <J.winkler@biocuresolutions.com>, Emily Hawkins <Emmy.h@biocuresolutions.com>, Gary Schuller <gary.schuller@biocuresolutions.com>, Sabrina Hall <Brina@biocuresolutions.com>, Sam Jonsson <Sjonsson@biocuresolutions.com>, Jeffrey Thiry <Jeff.thiry@biocuresolutions.com>, Daniel Jaen <Djaen@biocuresolutions.com>, Sean Myers <sean_myers@biocuresolutions.com>, Jacob Jansson <Jake.jansson@biocuresolutions.com>, Ottone Jones <ottone@biocuresolutions.com>, Raoul Wolfe <r.wolfe@biocuresolutions.com>, Floris Bailey <florisb@biocuresolutions.com>, Cameron Cabanas <Camc@biocuresolutions.com>, Suzanne Nerger <Snerger@biocuresolutions.com>
Date: 2024-03-04

CALENDAR INVITE

You are invited to: Vendor Management Team Team Meeting
Scheduled for: 2024-03-04

Organizer: Angela Ellis (Angel.e@biocuresolutions.com)

Attendees:
  - Charles Bruyere (Cbruyere@biocuresolutions.com)
  - John Davies (Jdavies@biocuresolutions.com)
  - Angela Ellis (Angel.e@biocuresolutions.com)
  - Jennifer Winkler (J.winkler@biocuresolutions.com)
  - Emily Hawkins (Emmy.h@biocuresolutions.com)
  - Gary Schuller (gary.schuller@biocuresolutions.com)
  - Sabrina Hall (Brina@biocuresolutions.com)
  - Sam Jonsson (Sjonsson@biocuresolutions.com)
  - Jeffrey Thiry (Jeff.thiry@biocuresolutions.com)
  - Daniel Jaen (Djaen@biocuresolutions.com)
  - Sean Myers (sean_myers@biocuresolutions.com)
  - Jacob Jansson (Jake.jansson@biocuresolutions.com)
  - Ottone Jones (ottone@biocuresolutions.com)
  - Raoul Wolfe (r.wolfe@biocuresolutions.com)
  - Floris Bailey (florisb@biocuresolutions.com)
  - Cameron Cabanas (Camc@biocuresolutions.com)
  - Suzanne Nerger (Snerger@biocuresolutions.com)

This meeting has been scheduled by Angela Ellis.

Please accept or decline this invitation at your earliest convenience.
<!-- END FETCHED CONTENT -->
